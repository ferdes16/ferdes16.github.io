# Day 04 — Clusters | Logistics clusters across Spain

Independent Day 4 prototype approved in the conversation. The earlier railway
concept remains in [issue #3](https://github.com/ferdes16/gis-map-lab/issues/3).
The download/analysis/render workflow does not publish automatically.

**Status: final 8 km poster selected and publication explicitly approved by the owner on 4 November 2026.**
Portfolio: [Logistics clusters across Spain](https://mappedbyfer.com/maps/2026/day-04-spain-logistics/).
Only the selected social and portfolio PNGs are committed; earlier visual trials
and large raw/processed datasets remain local and can be regenerated with the scripts.
The portfolio also provides a ZIP of this README, the complete R workflow and
validation reports so the OSM-derived analysis can be reconstructed from the
documented source snapshot. OSM-derived database content is under ODbL 1.0,
with attribution to © OpenStreetMap contributors.
Selected master PNG MD5: `963a85cb2a6e8eb303cb98d1aac70621`.
The exact requested tags produce a useful storage-feature map, but not an
independently verified inventory of current logistics centres. Small buildings
and local mapping/import practices materially influence the largest hotspots.

## Selected poster

The owner selected the version without the prominent road overlay and requested the following final
editorial changes: title **“Logistics clusters across Spain”**, no subtitle,
no cluster-name labels or leader lines, and no displayed cluster count. The
**25,249 mapped objects** count and KDE legend remain. The bottom-right footer
reads `#30DayMapChallenge 2026`, `Day 4 — Clusters` and `@mappedbyfer`; OSM and
Geofabrik attribution and the licence URL are at bottom left. The filter note
reads `OSM filters: warehouses, logistics and trucking.`
The exact five tag predicates are documented below.

The selected poster omits the explanatory sentence starting “Includes small
storage buildings”, as requested by the owner. The data limitations remain
documented in this README.

The selected version restores the initial prototype's faint grey motorway/trunk
context (`#73818A`, alpha 0.12, linewidth 0.10), at the owner's request. The
prominent gold road overlay remains a separate variant. Its points, cluster
calculation and KDE are unchanged.
The former WHERE SPAIN MOVES images are retained as earlier prototypes.

- [Selected social PNG](output/logistics-clusters-across-spain-social.png): 2400 × 2700 px.
- [Selected portfolio PNG](output/logistics-clusters-across-spain-portfolio.png): 4800 × 5400 px.
- `output/render-info-selected.json`: title, suppressed labels/count, footer and scale settings.
- Reproduce with `Rscript maps/day-04-spain-logistics/scripts/render.R` from the repository root.

## Question and counting unit

Where do OpenStreetMap's specifically tagged storage and logistics objects
concentrate across mainland Spain? This is a map of **mapped features**, not a
complete inventory of active logistics companies, freight traffic or economic
importance. A logistics campus may have multiple mapped warehouse buildings.

The design follows the owner's dark cyan/mint direction. The KDE is the main
visual layer, with fine observed-object points; roads serve only as subtle
context. The selected poster has no cluster labels.

## Sources, snapshot and reuse

| Source | Use | Conditions |
|---|---|---|
| [OpenStreetMap via Geofabrik Spain](https://download.geofabrik.de/europe/spain.html) | Logistics features and major road lines; original `.osm.pbf` | [ODbL 1.0](https://opendatacommons.org/licenses/odbl/1-0/), © OpenStreetMap contributors |
| [Natural Earth 10m countries](https://www.naturalearthdata.com/downloads/10m-cultural-vectors/10m-admin-0-countries/) | Mainland mask/outline | [Public domain](https://www.naturalearthdata.com/about/terms-of-use/) |
| OSM `place=city/town`, same Geofabrik PBF | Final cluster label references: 881 mainland named places | ODbL 1.0 |
| [Natural Earth populated places](https://www.naturalearthdata.com/downloads/10m-cultural-vectors/10m-populated-places/) | Initial/fallback reference, retained in context | Public domain |

OSM snapshot: **2026-11-03**, pinned asset `spain-261103.osm.pbf`, 1,498,353,321
bytes. The provider MD5 sidecar is checked before conversion. Original sources
and processed datasets are kept locally under `data/`; repository rules ignore
these large files. `output/sources.json` records URLs and checksums. If Geofabrik
eventually removes the dated daily asset, retain this cached snapshot rather
than silently replacing it with a newer extract.

The poster includes the OSM attribution and licence URL. OSM-derived databases
are subject to ODbL obligations on redistribution; provide the licence and
attribution with any exported dataset. A rendered map is a Produced Work;
follow [OSMF attribution guidance](https://osmfoundation.org/wiki/Licence/Attribution_Guidelines).
Natural Earth boundaries are cartographic, not authoritative cadastral limits.

## Acquisition and tag filters

The GDAL OSM driver processes the full Spain PBF, using a project-specific
`scripts/osmconf.ini` and one filter over point, line and polygon layers. It
retains OSM element type/ID, version/timestamp when present, dedicated matching
tags, and `all_tags` as JSON. Closed industrial-only ways are treated as areas.

An object qualifies if **any** of the following is true:

- `building=warehouse`
- `building:use=warehouse`
- `industrial=warehouse`
- `industrial=logistics`
- `industrial=trucking`

`landuse=industrial` alone never qualifies. Only `highway=motorway` and `trunk`
are extracted for the very faint road context. No residential or local roads
are added. The original PBF is preserved alongside the filtered GeoPackage.

## Geometry, scope and duplicate handling

All analysis uses **ETRS89 / LAEA Europe, EPSG:3035**, in metres. The largest
connected Spain polygon in Natural Earth defines the mainland mask, excluding
the Balearic/Canary Islands, Ceuta, Melilla and offshore islands. Points are
retained by exact intersection with that mask. Small discrepancies at shores
and borders can exclude real facilities; all such exclusions are audited.

1. Repair invalid geometries and report empty results.
2. Exclude objects explicitly marked `disused=yes/true/1` or
   `abandoned=yes/true/1`. Other objects' current activity is not assumed verified.
3. Resolve repeated OSM type/ID records, preferring polygon geometry.
4. Remove topologically equal geometries.
5. Use an interior representative point (`st_point_on_surface`) for each object.
6. Avoid counting a selected node again when it lies in an already selected
   warehouse/logistics building footprint; retain an audit with the parent ID.
7. Preserve broader logistics-site polygons enclosing selected buildings, but
   exclude those enclosing site objects from point density/clustering.
8. Collapse coincident representative points at millimetre precision for the
   point analysis while retaining underlying source geometry records.

`data/processed/logistics.gpkg` preserves original repaired geometries, area,
category and inclusion flags, plus representative and clustered point layers.
Area is available for inspection; **KDE and DBSCAN weight every point equally**.
Warehouse-related tags and broader logistics/trucking objects are distinguished
in validation tables and cluster summaries. Building footprints are not the
same thing as site area or floor area across multiple storeys.

## Clustering

Primary method: **DBSCAN, eps = 3,000 m, minPts = 10**, border points included.
The radius describes proximity between warehouse objects at the scale of
industrial estates and nearby groups; ten objects limits tiny groups. A cluster
can extend much farther than 3 km through density-connected chains. These
parameters do not define a metropolitan boundary or prove significance.

The pipeline checks radii 1.5/3/5 km and minPts 5/10/20 and exports cluster/noise
counts, largest-group size and clustered share. Ninth-neighbour distances are
also recorded. Core status is verified against each point's actual neighbour
count, including itself. Each reported cluster must contain core points, and
cluster object counts reconcile with memberships.

Label anchors are actual observations with the densest local neighbourhood
within each cluster. A nearby OSM city/town supplies the final geographic label;
it is prefixed with “Near” if more than 12 km away, and labels beyond 45 km are
omitted. The renderer selects the largest groups first, avoiding anchors within
55 km of an already labelled group; up to ten labels are shown. Natural Earth
cities served as a first-pass reference but missed towns near large groups, so
`extract-places.R` retrieves city/town references from the same original PBF.
Labels identify concentrations present in this source, not independently
certified logistics hubs or an economic ranking.

## KDE and design

Gaussian count KDE with **sigma = 8 km**, evaluated on a roughly **2 km grid**
in projected metres. `MASS::kde2d` internally divides its supplied `h` by four,
so the script passes `h = 32,000` to achieve the stated 8 km standard deviation.
The output is multiplied by point count and 1,000,000 to express **mapped objects
per km²**. Noise points remain included; DBSCAN membership does not artificially
erase isolated facilities from the map.

The KDE has 40 km of padding before clipping to the mainland. Its pre-mask
integral is checked against the number of objects, and GeoTIFF values are
checked against evaluation-grid coordinates to prevent transposed rasters.
Land clipping has no boundary correction, so coastal densities can lose mass.
Grid resolution does not imply 2 km positional accuracy or independent cells.

The dark poster uses a sequential charcoal/teal/mint/white palette and square-root
colour scaling. The 99.9th percentile of positive mainland density values caps
the visual range; the legend marks its high endpoint with `≥`. The stored KDE
is not capped. Fine mint points locate individual objects; pale points indicate
DBSCAN core observations. No freight flows are inferred from the contextual roads.

## Reproduce

From the repository root:

```sh
Rscript maps/day-04-spain-logistics/scripts/download.R
Rscript maps/day-04-spain-logistics/scripts/extract.R
Rscript maps/day-04-spain-logistics/scripts/prepare.R
Rscript maps/day-04-spain-logistics/scripts/extract-places.R
Rscript maps/day-04-spain-logistics/scripts/analyse.R
Rscript maps/day-04-spain-logistics/scripts/render.R
```

R dependencies: sf/GDAL with OSM support, osmextract (OSM config), dplyr, ggplot2, MASS, terra, ragg,
jsonlite and dbscan. Downloading uses curl. The original environment has all
except dbscan, installed in **this prototype's `data/library/`**, not globally.
The cached CRAN macOS ARM64 binary is 1.2.7; other platforms can install from CRAN.
R session/package versions are exported. Typography: DIN Condensed and Avenir
Next, available on the project machine; substitute installed sans fonts elsewhere.

## Deliverables and limitations

- `data/raw/spain-261103.osm.pbf` and `.md5`: original OSM snapshot/checksum.
- `data/raw/osm-logistics-and-motorways.gpkg`: filtered original tags/geometries.
- `data/raw/osm-settlements.gpkg`: same-snapshot place references for labels.
- `data/processed/logistics.gpkg`: source geometry and analysis point layers.
- `data/processed/context.gpkg`: mainland, roads and label-reference cities.
- `data/processed/logistics-kde-8km.tif`: uncapped projected density raster.
- `output/01-raw-logistics-points.png`: required first point-map prototype.
- `output/where-spain-moves-social.png`: 2400 × 2700 px.
- `output/where-spain-moves-portfolio.png`: 4800 × 5400 px.
- `output/validation.json`, `cleaning-audit.csv`, `category-counts.csv`,
  `matching-tag-counts.csv`, `building-size-diagnostics.csv`,
  `cluster-building-size-diagnostics.csv`, `dbscan-sensitivity.csv`, `cluster-summary.csv`, `analysis.json`,
  `label-anchors.csv`, `render-info.json`, `sources.json`, `session-info.txt`.

OSM completeness and tag usage vary regionally. `building=warehouse` describes
building form/original purpose and does not by itself confirm present logistics
operations. Agricultural or other storage buildings can be included. Large
facilities without these tags are omitted. Visible clusters therefore reflect
both real objects and mapping practice. KDE smoothing, point definitions and
DBSCAN parameters influence patterns; no economic importance or freight volume
is established.

## Completed validation and findings

| Measure | Result |
|---|---:|
| Initial specifically tagged candidate objects | 28,213 |
| Invalid geometries before repair | 4 |
| Explicitly disused/abandoned, excluded | 21 |
| Outside the mainland land mask, excluded | 2,882 |
| Topologically identical geometries removed | 1 |
| Nodes represented by selected building footprints | 2 |
| Broader enclosing sites retained as geometry but excluded from point analysis | 56 |
| Coincident representative point rows collapsed | 2 |
| Final mapped analysis objects | **25,249** |
| Warehouse-tagged objects | **25,207** |
| Broader logistics/trucking objects | **42** |
| DBSCAN groups at 3 km / 10 objects | **200** |
| Objects in DBSCAN groups | 22,217 (88.0%) |
| Objects classified as DBSCAN noise | 3,032 |
| Invalid final geometries / repeated point OSM IDs | **0 / 0** |

The KDE uses a 546 × 484 grid, approximately 1,997 × 1,999 m cells. Its padded,
pre-mask integral is 25,249 objects, matching the source sample. Raw maximum
mainland density is 5.30 objects/km²; the display cap is 2.87 objects/km² and is
explicitly marked in the legend. Both uncapped values and geometries remain
available in the processed datasets.

**The main analytical limitation is substantial:** of 25,081 mapped building
footprints, the median area is only **103.8 m²**; 12,223 are below 100 m² and
20,776 below 500 m². Only 2,220 are at least 1,000 m². No arbitrary area filter
was applied, since it would redefine the requested tag-based sample and remove
real source features. The broad extraction is preserved transparently.

The largest mapped groups contain 2,135 objects near Quintanar de la Orden,
1,696 around Deltebre and 1,200 near Fregenal de la Sierra. Their median footprint
areas are approximately 92.5, 40.8 and 66.6 m² respectively. Source tags inspected
at dense anchors include Catastro imports. These are genuine concentrations of
the selected OSM objects, but **not evidence that these locations dominate
Spain's commercial logistics**. Mapping patterns and small storage buildings
can dominate an unweighted count map. Larger tagged groups also appear near
San Martín de la Vega, Lugo, Burgos, Torre-Pacheco and el Prat de Llobregat.

Sensitivity results: cluster membership ranges from 77.5% to 95.0% across the
nine documented parameter combinations. With minPts fixed at ten, the group
count changes from 211 (1.5 km) to 200 (3 km) to 172 (5 km). These are descriptive
density-connected groups; counts are not statistically significant cluster tests.

This prototype fulfils the requested OSM tag definition and editorial treatment.
Its visual claim is limited to mapped storage/logistics feature concentration.
The mapped-object count and this documentation define that scope. A claim about active,
large logistics centres would require a separately justified definition or an
independent operational-facility source.

## Road-overlay variant

At the owner's request, a separate composition makes the main OSM road network
visible over the density surface, allowing visual comparison of road corridors
and mapped object concentrations. The KDE, DBSCAN memberships, points, labels,
extent and density scale remain identical to the first poster.

The cached same-snapshot road layer contains 44,867 `highway=motorway` and 59,906
`highway=trunk` geometry features intersecting the mainland mask. These are OSM
segments, including separate carriageways, not counts of unique routes.
Geometry was simplified to 120 m during preparation for this national-scale map.
Motorways use muted warm gold with a faint casing; trunk roads use cooler grey.
Both appear above the KDE and below the individual feature points and labels.

This is a road-network overlay, not an assertion that each cluster is connected
to another by a measured logistics route. No freight traffic, shortest-path
routing or network-connectivity analysis has been added. Road categories follow
OSM tagging rather than an independent legal road classification.

```sh
Rscript maps/day-04-spain-logistics/scripts/render.R --roads
```

Separate exports preserve the first version:

- `output/where-spain-moves-roads-social.png`: 2400 × 2700 px.
- `output/where-spain-moves-roads-portfolio.png`: 4800 × 5400 px.
- `output/render-info-roads.json`: source class counts and render settings.
- `output/label-anchors-roads.csv`: identical cluster-label observations.

## KDE bandwidth trials: 5 and 10 km

At the owner's request, two separate trials change only the Gaussian standard
deviation to 5 km and 10 km. They retain the selected poster's title/footer,
subtle roads, unlabelled points, mapped-object count, extent, mainland mask,
546 × 484 evaluation grid, palette and square-root colour transform. Both use
the **exact 8 km reference colour cap of 2.86700946 objects/km²**, with the same
`≥` endpoint. Separate rescaling per map would conceal peak-intensity changes.
The 8 km selected files remain the reference rather than being replaced.

| Gaussian sigma | Input objects | Integrated objects before land mask | Maximum mainland density (objects/km²) |
|---|---:|---:|---:|
| 5 km | 25,249 | 25,249 | 13.381 |
| 8 km | 25,249 | 25,249 | 5.298 |
| 10 km | 25,249 | 25,249 | 3.404 |

Visual review confirms that 5 km produces smaller, sharper peaks and separates
nearby concentrations; 10 km spreads the glow and combines more local patterns.
These are descriptive smoothing alternatives, not statistical proof that one
bandwidth is optimal. Density remains an equal-weight count of the same source
objects; DBSCAN is not recalculated. Exact grid coordinates, integrals, finite
nonnegative density, raster orientation and shared rendering settings are checked.

```sh
Rscript maps/day-04-spain-logistics/scripts/kde-bandwidth-trials.R
# Or render either already-computed surface independently:
Rscript maps/day-04-spain-logistics/scripts/render.R --kde-km=5
Rscript maps/day-04-spain-logistics/scripts/render.R --kde-km=10
```

Outputs:

- `output/logistics-clusters-across-spain-kde-5km-social.png` and
  `output/logistics-clusters-across-spain-kde-10km-social.png`: 2400 × 2700 px.
- Matching `-portfolio.png` files: 4800 × 5400 px.
- `output/kde-comparison-5-8-10km.png`: side-by-side review sheet, 2400 × 950 px.
- `data/processed/density-surface-5km.rds`, `density-surface-10km.rds` and matching
  `logistics-kde-5km.tif`, `logistics-kde-10km.tif`: uncapped computed surfaces.
- `output/kde-bandwidth-comparison.csv`: counts, integrals, maxima and colour clipping.
- `output/render-info-selected-kde-5km.json` and `render-info-selected-kde-10km.json`:
  individual metadata with the common 8 km colour reference.

The optional review-sheet composition uses the installed R `png` package; the
individual scientific surfaces and final PNGs use the existing workflow.
