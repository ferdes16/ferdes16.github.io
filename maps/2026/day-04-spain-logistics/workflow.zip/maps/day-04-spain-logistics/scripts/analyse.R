source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
stopifnot(requireNamespace("dbscan",quietly=TRUE))
points <- readRDS(file.path(processed_dir,"facility-points.rds"))
mainland <- st_read(file.path(processed_dir,"context.gpkg"),layer="mainland",quiet=TRUE)
context_file <- file.path(processed_dir,"context.gpkg")
city_layer <- if("osm_towns" %in% st_layers(context_file)$name) "osm_towns" else "cities"
cities <- st_read(context_file,layer=city_layer,quiet=TRUE)
xy <- st_coordinates(points)
stopifnot(st_crs(points)$epsg==crs_analysis,nrow(points)>=10)
eps <- 3000
min_pts <- 10L
sensitivity <- bind_rows(lapply(c(1500,3000,5000),function(radius)
  bind_rows(lapply(c(5L,10L,20L),function(n) {
    fit <- dbscan::dbscan(xy,eps=radius,minPts=n)
    sizes <- table(fit$cluster[fit$cluster>0])
    data.frame(eps_m=radius,min_points=n,clusters=length(sizes),noise=sum(fit$cluster==0),
      clustered_share_pct=100*mean(fit$cluster>0),largest_cluster=if(length(sizes)) max(sizes) else 0)
  }))))
write.csv(sensitivity,file.path(out_dir,"dbscan-sensitivity.csv"),row.names=FALSE)
size_summary <- points |> st_drop_geometry() |> filter(building_footprint) |>
  summarise(mapped_buildings=n(),median_footprint_m2=median(footprint_area_m2),
    smaller_than_100_m2=sum(footprint_area_m2<100),
    smaller_than_500_m2=sum(footprint_area_m2<500),
    at_least_1000_m2=sum(footprint_area_m2>=1000))
write.csv(size_summary,file.path(out_dir,"building-size-diagnostics.csv"),row.names=FALSE)
fit <- dbscan::dbscan(xy,eps=eps,minPts=min_pts,borderPoints=TRUE)
points$cluster_id <- fit$cluster
neighbours <- dbscan::frNN(xy,eps=eps,sort=FALSE)$id
points$neighbours_within_eps <- vapply(seq_along(neighbours),function(i)
  length(unique(c(i,neighbours[[i]]))),integer(1))
points$core_point <- points$neighbours_within_eps>=min_pts
size_by_cluster <- points |> st_drop_geometry() |> group_by(cluster_id) |>
  summarise(objects=n(),median_footprint_m2=median(footprint_area_m2,na.rm=TRUE),
    buildings_under100_m2=sum(footprint_area_m2<100,na.rm=TRUE),.groups="drop")
write.csv(size_by_cluster,file.path(out_dir,"cluster-building-size-diagnostics.csv"),row.names=FALSE)
stopifnot(all(points$cluster_id[points$core_point]>0))
if(any(points$cluster_id>0)) {
  cs <- st_drop_geometry(points) |> filter(cluster_id>0) |> group_by(cluster_id) |>
    summarise(objects=n(),warehouse_objects=sum(category=="Warehouse"),
      broader_logistics_objects=sum(category!="Warehouse"),core_points=sum(core_point),
      building_area_m2=sum(footprint_area_m2[building_footprint],na.rm=TRUE),.groups="drop") |>
    arrange(desc(objects))
  stopifnot(all(cs$core_points>0),sum(cs$objects)==sum(points$cluster_id>0))
  # Anchor labels at a real point with the densest local neighbourhood, not an
  # invented economic hub or a centroid in an empty part of a chained cluster.
  anchors <- points |> filter(cluster_id>0) |> arrange(desc(neighbours_within_eps),feature_id) |>
    group_by(cluster_id) |> slice_head(n=1) |> ungroup()
  near <- st_nearest_feature(anchors,cities)
  anchors$near_city <- cities$name[near]
  anchors$city_distance_km <- as.numeric(st_distance(anchors,cities[near,],by_element=TRUE))/1000
  anchors$objects <- cs$objects[match(anchors$cluster_id,cs$cluster_id)]
  anchors$label_reference <- city_layer
  anchors$label <- ifelse(anchors$city_distance_km<=12,anchors$near_city,paste("Near",anchors$near_city))
  anchors$label <- recode(anchors$label,"Seville"="Sevilla","Near Seville"="Near Sevilla",
    "La Coruña"="A Coruña","Near La Coruña"="Near A Coruña")
  cs <- left_join(cs,st_drop_geometry(anchors) |> select(cluster_id,near_city,city_distance_km),by="cluster_id")
  save_gpkg(anchors,"clusters.gpkg","cluster_anchors")
  write.csv(cs,file.path(out_dir,"cluster-summary.csv"),row.names=FALSE)
} else stop("No density-connected clusters at selected settings; review the data before rendering.")
save_gpkg(points,"logistics.gpkg","clustered_points")
saveRDS(points,file.path(processed_dir,"clustered-points.rds"))
kdist <- dbscan::kNNdist(xy,k=min_pts-1)
write.csv(data.frame(probability=c(.1,.25,.5,.75,.9,.95,.99),
  ninth_neighbour_m=as.numeric(quantile(kdist,c(.1,.25,.5,.75,.9,.95,.99)))),
  file.path(out_dir,"nearest-neighbour-diagnostics.csv"),row.names=FALSE)

# Count KDE of all retained objects, including DBSCAN noise; each object weighs 1.
# MASS::kde2d internally divides h by 4. Pass 4*sigma to obtain an 8 km Gaussian.
bw <- 8000
resolution <- 2000
extent <- st_bbox(st_buffer(mainland,40000))
lims <- unname(extent[c("xmin","xmax","ymin","ymax")])
nx <- ceiling((lims[2]-lims[1])/resolution)+1
ny <- ceiling((lims[4]-lims[3])/resolution)+1
message("KDE on ",nx," × ",ny," grid; ",nrow(points)," real objects.")
kde <- MASS::kde2d(xy[,1],xy[,2],h=rep(4*bw,2),n=c(nx,ny),lims=lims)
z <- expand.grid(x=kde$x,y=kde$y)
z$density_per_km2 <- as.vector(kde$z)*nrow(points)*1e6
stopifnot(all(is.finite(z$density_per_km2)),all(z$density_per_km2>=0))
mask_points <- st_as_sf(z,coords=c("x","y"),crs=crs_analysis)
z$on_mainland <- lengths(st_intersects(mask_points,mainland))>0
grid_dx <- diff(kde$x)[1]; grid_dy <- diff(kde$y)[1]
mass_total <- sum(z$density_per_km2)*grid_dx*grid_dy/1e6
# 40 km (five sigma) padding captures essentially the whole mass before clipping.
stopifnot(abs(mass_total/nrow(points)-1)<.02)
saveRDS(z,file.path(processed_dir,"density-surface.rds"))
surface <- terra::rast(nrows=ny,ncols=nx,xmin=min(kde$x)-grid_dx/2,
  xmax=max(kde$x)+grid_dx/2,ymin=min(kde$y)-grid_dy/2,ymax=max(kde$y)+grid_dy/2,
  crs=paste0("EPSG:",crs_analysis))
terra::values(surface) <- as.vector(kde$z[,ny:1])*nrow(points)*1e6
sample_i <- c(1L,as.integer(nrow(z)/2),nrow(z))
extracted <- terra::extract(surface,as.matrix(z[sample_i,c("x","y")]))[,1]
stopifnot(isTRUE(all.equal(as.numeric(extracted),z$density_per_km2[sample_i],tolerance=1e-8)))
terra::writeRaster(surface,file.path(processed_dir,"logistics-kde-8km.tif"),overwrite=TRUE)
write_json_pretty(list(analysis_objects=nrow(points),warehouse_objects=sum(points$category=="Warehouse"),
  broader_logistics_objects=sum(points$category!="Warehouse"),
  label_reference_layer=city_layer,building_sizes=size_summary,
  dbscan=list(eps_m=eps,minPts=min_pts,clusters=nrow(cs),noise_objects=sum(points$cluster_id==0),
    clustered_objects=sum(points$cluster_id>0),core_objects=sum(points$core_point),
    interpretation="descriptive density-connected groups, not tested significant clusters"),
  kde=list(gaussian_sigma_m=bw,MASS_h_argument=4*bw,grid=c(nx,ny),
    actual_cell_metres=c(grid_dx,grid_dy),units="mapped objects per square kilometre",
    integral_before_land_mask=mass_total,source_object_count=nrow(points),
    maximum_density=max(z$density_per_km2[z$on_mainland]),
    land_mask="Natural Earth mainland Spain; no boundary correction"),
  crs_epsg=crs_analysis),"analysis.json")
capture.output(sessionInfo(),file=file.path(out_dir,"session-info.txt"))
print(head(cs,15))
