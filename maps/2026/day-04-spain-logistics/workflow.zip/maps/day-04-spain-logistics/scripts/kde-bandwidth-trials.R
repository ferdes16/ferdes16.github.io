# Compare 5 and 10 km Gaussian sigmas against the existing 8 km reference.
source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
points <- readRDS(file.path(processed_dir,"clustered-points.rds"))
xy <- st_coordinates(points)
reference <- readRDS(file.path(processed_dir,"density-surface.rds"))
grid_x <- sort(unique(reference$x)); grid_y <- sort(unique(reference$y))
dx <- diff(grid_x)[1]; dy <- diff(grid_y)[1]
limit <- quantile(reference$density_per_km2[reference$on_mainland & reference$density_per_km2>1e-5],.999)
summary_row <- function(z,km) data.frame(sigma_km=km,objects=nrow(points),
  integral_before_land_mask=sum(z$density_per_km2)*dx*dy/1e6,
  maximum_density_per_km2=max(z$density_per_km2[z$on_mainland]),
  shared_colour_cap=unname(limit),
  mainland_pixels_above_cap=sum(z$on_mainland & z$density_per_km2>limit),
  mainland_pixels=sum(z$on_mainland))
results <- list(summary_row(reference,8))
for(km in c(5,10)) {
  message("Computing ",km," km KDE on the unchanged reference grid.")
  # MASS divides h by 4 internally; pass four times the desired Gaussian sigma.
  kde <- MASS::kde2d(xy[,1],xy[,2],h=rep(4*km*1000,2),
    n=c(length(grid_x),length(grid_y)),lims=c(range(grid_x),range(grid_y)))
  z <- reference[,c("x","y","on_mainland")]
  stopifnot(isTRUE(all.equal(kde$x,grid_x)),isTRUE(all.equal(kde$y,grid_y)))
  z$density_per_km2 <- as.vector(kde$z)*nrow(points)*1e6
  stopifnot(all(is.finite(z$density_per_km2)),all(z$density_per_km2>=0),
    abs(sum(z$density_per_km2)*dx*dy/1e6/nrow(points)-1)<.02)
  saveRDS(z,file.path(processed_dir,paste0("density-surface-",km,"km.rds")))
  raster <- terra::rast(nrows=length(grid_y),ncols=length(grid_x),
    xmin=min(grid_x)-dx/2,xmax=max(grid_x)+dx/2,ymin=min(grid_y)-dy/2,ymax=max(grid_y)+dy/2,
    crs=paste0("EPSG:",crs_analysis))
  terra::values(raster) <- as.vector(kde$z[,length(grid_y):1])*nrow(points)*1e6
  sample_i <- c(1L,as.integer(nrow(z)/2),nrow(z))
  check <- terra::extract(raster,as.matrix(z[sample_i,c("x","y")]))[,1]
  stopifnot(isTRUE(all.equal(as.numeric(check),z$density_per_km2[sample_i],tolerance=1e-8)))
  terra::writeRaster(raster,file.path(processed_dir,paste0("logistics-kde-",km,"km.tif")),overwrite=TRUE)
  results[[length(results)+1]] <- summary_row(z,km)
}
comparison <- bind_rows(results) |> arrange(sigma_km)
write.csv(comparison,file.path(out_dir,"kde-bandwidth-comparison.csv"),row.names=FALSE)
for(km in c(5,10)) {
  status <- system2(file.path(R.home("bin"),"Rscript"),c(shQuote(file.path(root,"scripts/render.R")),paste0("--kde-km=",km)))
  stopifnot(status==0)
}
if(requireNamespace("png",quietly=TRUE)) {
  # A review sheet only; individual posters retain full social/portfolio size.
  ragg::agg_png(file.path(out_dir,"kde-comparison-5-8-10km.png"),
    width=2400,height=950,res=160,background=bg)
  grid::grid.newpage()
  for(i in seq_along(c(5,8,10))) {
    km <- c(5,8,10)[i]
    name <- if(km==8) "logistics-clusters-across-spain-social.png" else
      paste0("logistics-clusters-across-spain-kde-",km,"km-social.png")
    img <- png::readPNG(file.path(out_dir,name))
    grid::grid.raster(img,x=(i-.5)/3,y=.475,width=1/3,height=900/950,interpolate=TRUE)
    grid::grid.text(paste0(km," km",if(km==8) " · reference" else ""),x=(i-.5)/3,y=.974,
      gp=grid::gpar(col="#E5FFF7",fontfamily="Avenir Next",fontsize=14,fontface="bold"))
  }
  dev.off()
}
print(comparison)
