source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
pbf_name <- "spain-261103.osm.pbf"
base <- "https://download.geofabrik.de/europe/"
fetch(paste0(base,pbf_name,".md5"),file.path(raw_dir,paste0(pbf_name,".md5")))
pbf <- file.path(raw_dir,pbf_name)
# Accept a completed externally downloaded .part only after checksum verification.
expected_md5 <- strsplit(readLines(paste0(pbf,".md5"))[1]," +")[[1]][1]
if(!file.exists(pbf) && file.exists(paste0(pbf,".part")) &&
   file.info(paste0(pbf,".part"))$size==1498353321) {
  stopifnot(unname(tools::md5sum(paste0(pbf,".part")))==expected_md5)
  stopifnot(file.rename(paste0(pbf,".part"),pbf))
}
fetch(paste0(base,pbf_name),pbf)
stopifnot(unname(tools::md5sum(pbf))==expected_md5)
sources <- list(list(file=pbf_name,url=paste0(base,pbf_name),md5=expected_md5,
  snapshot="2026-11-03",licence="ODbL 1.0",bytes=file.info(pbf)$size))
for(stem in c("ne_10m_admin_0_countries","ne_10m_populated_places_simple")) {
  zip <- file.path(raw_dir,paste0(stem,".zip"))
  url <- paste0("https://naturalearth.s3.amazonaws.com/10m_cultural/",stem,".zip")
  fetch(url,zip)
  dir <- file.path(raw_dir,stem)
  if(!dir.exists(dir)) unzip(zip,exdir=dir)
  sources[[length(sources)+1]] <- list(file=basename(zip),url=url,
    md5=unname(tools::md5sum(zip)),licence="Public domain")
}
write_json_pretty(list(retrieved_at_utc=format(Sys.time(),tz="UTC",usetz=TRUE),sources=sources),"sources.json")
if(!requireNamespace("dbscan",quietly=TRUE)) {
  # One optional dependency, isolated to this prototype rather than a global library.
  archive <- file.path(raw_dir,"dbscan_1.2.7.tgz")
  if(file.exists(archive) && Sys.info()["sysname"]=="Darwin")
    install.packages(archive,repos=NULL,type="binary",lib=local_library)
  else install.packages("dbscan",repos="https://cloud.r-project.org",lib=local_library)
}
message("Original OSM snapshot checksum verified; contextual sources cached.")
