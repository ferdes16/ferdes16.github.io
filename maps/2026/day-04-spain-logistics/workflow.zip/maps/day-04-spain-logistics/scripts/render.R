source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
suppressPackageStartupMessages(library(grid))
roads_version <- "--roads" %in% commandArgs(TRUE)
suffix <- if(roads_version) "-roads" else "-selected"
output_stem <- if(roads_version) "where-spain-moves-roads" else "logistics-clusters-across-spain"
map_title <- if(roads_version) "WHERE SPAIN MOVES" else "Logistics clusters across Spain"
kde_arg <- grep("^--kde-km=",commandArgs(TRUE),value=TRUE)
kde_km <- if(length(kde_arg)) as.numeric(sub("^--kde-km=","",kde_arg[1])) else 8
stopifnot(length(kde_km)==1,is.finite(kde_km),kde_km>0)
if(kde_km!=8) {
  suffix <- paste0(suffix,"-kde-",kde_km,"km")
  output_stem <- paste0(output_stem,"-kde-",kde_km,"km")
}
points <- readRDS(file.path(processed_dir,"clustered-points.rds"))
reference_surface <- readRDS(file.path(processed_dir,"density-surface.rds"))
surface <- if(kde_km==8) reference_surface else
  readRDS(file.path(processed_dir,paste0("density-surface-",kde_km,"km.rds")))
mainland <- st_read(file.path(processed_dir,"context.gpkg"),layer="mainland",quiet=TRUE)
roads <- st_read(file.path(processed_dir,"context.gpkg"),layer="major_roads",quiet=TRUE)
anchors <- st_read(file.path(processed_dir,"clusters.gpkg"),layer="cluster_anchors",quiet=TRUE)
analysis <- read_json(file.path(out_dir,"analysis.json"),simplifyVector=TRUE)
extent <- st_bbox(st_buffer(mainland,45000))
palette <- c(bg,"#12373E","#2E807F","#4EE4D0","#E5FFF7")
colour_values <- c(0,.18,.4,.75,1)
# All bandwidth trials reuse the 8 km poster's exact colour range, not separate
# percentile scales that would conceal the change in peak intensity.
positive <- reference_surface$density_per_km2[reference_surface$on_mainland & reference_surface$density_per_km2>1e-5]
limit <- as.numeric(quantile(positive,.999))
surface$shown_density <- ifelse(surface$on_mainland,surface$density_per_km2,NA_real_)
xy <- st_coordinates(points)
dots <- data.frame(x=xy[,1],y=xy[,2],cluster=points$cluster_id,core=points$core_point)
eligible <- anchors |> arrange(desc(objects)) |> filter(city_distance_km<=45) |>
  distinct(near_city,.keep_all=TRUE)
# Avoid dense overlapping labels while keeping the largest mapped groups first.
chosen <- integer()
for(i in seq_len(nrow(eligible))) {
  if(!length(chosen) || all(as.numeric(st_distance(eligible[i,],eligible[chosen,]))>=55000))
    chosen <- c(chosen,i)
  if(length(chosen)>=10) break
}
labels <- eligible[chosen,]
lxy <- st_coordinates(labels)
labels$x <- lxy[,1]; labels$y <- lxy[,2]
# Simple outward offsets; final label positions are visually reviewed.
labels$right_side <- labels$x>mean(extent[c("xmin","xmax")])
labels$label_x <- labels$x+ifelse(labels$right_side,-30000,30000)
labels$label_y <- labels$y+26000
labels$hjust <- ifelse(labels$right_side,1,0)
labels <- st_drop_geometry(labels)
road_layers <- if(roads_version) list(
  geom_sf(data=filter(roads,highway=="trunk"),colour="#7C8B92",alpha=.47,linewidth=.14),
  geom_sf(data=filter(roads,highway=="motorway"),colour="#C3AC7C",alpha=.12,linewidth=.75),
  geom_sf(data=filter(roads,highway=="motorway"),colour="#C3AC7C",alpha=.72,linewidth=.23)
) else list(geom_sf(data=roads,colour="#73818A",alpha=.12,linewidth=.10))
label_layers <- if(roads_version) list(
  geom_segment(data=labels,aes(x=x,y=y,xend=label_x,yend=label_y),
    colour="#8BAFA9",linewidth=.22,alpha=.75),
  geom_point(data=labels,aes(x,y),colour="#E5FFF7",size=.45),
  geom_label(data=labels,aes(x=label_x,y=label_y,label=label,hjust=hjust),
    family="Avenir Next",fontface="plain",size=3.1,colour="#DDF8EF",fill=bg,
    linewidth=0,label.padding=unit(.16,"lines"))
) else list()
p <- ggplot() +
  geom_sf(data=mainland,fill="#0B1A23",colour="#263844",linewidth=.25) +
  geom_raster(data=surface,aes(x,y,fill=shown_density),interpolate=FALSE) +
  scale_fill_gradientn(colours=palette,values=colour_values,trans="sqrt",
    limits=c(0,limit),oob=scales::squish,na.value="transparent") +
  road_layers +
  geom_point(data=dots,aes(x,y),colour="#4EE4D0",size=.60,alpha=.035,stroke=0) +
  geom_point(data=dots,aes(x,y),colour="#4EE4D0",size=.16,alpha=.62,stroke=0) +
  geom_point(data=filter(dots,core),aes(x,y),colour="#E5FFF7",size=.12,alpha=.70,stroke=0) +
  geom_sf(data=mainland,fill=NA,colour="#304955",linewidth=.25) +
  label_layers +
  coord_sf(xlim=unname(extent[c("xmin","xmax")]),ylim=unname(extent[c("ymin","ymax")]),datum=NA,expand=FALSE) +
  theme_void() + theme(legend.position="none",plot.background=element_rect(fill=bg,colour=NA),
    panel.background=element_rect(fill=bg,colour=NA),plot.margin=margin(0,0,0,0))
txt <- function(label,x,y,size=12,col="#DDF8EF",family="Avenir Next",face="plain",just="left")
  grid.text(label,x=x,y=y,just=just,gp=gpar(fontfamily=family,fontsize=size,col=col,fontface=face))
render <- function(file,width,height,dpi) {
  ragg::agg_png(file,width=width,height=height,res=dpi,background=bg)
  on.exit(dev.off())
  grid.newpage()
  if(roads_version) {
    txt("30DAYMAPCHALLENGE 2026",.065,.967,10,"#6F9898",face="bold")
    txt("DAY 04 / CLUSTERS",.935,.967,10,"#6F9898",face="bold",just="right")
    txt(map_title,.062,.912,62,"#E5FFF7",family="DIN Condensed",face="bold")
    txt("The hidden geography of logistics clusters in Spain.",.065,.865,15,"#9EC5BD")
    txt("OSM-tagged storage features and the main road network · all mapped building sizes",.065,.847,9,"#6F9898")
  } else txt(map_title,.062,.936,56,"#E5FFF7",family="DIN Condensed",face="bold")
  print(p,newpage=FALSE,vp=viewport(x=.5,y=if(roads_version) .515 else .53,
    width=.965,height=if(roads_version) .65 else .68))
  if(roads_version) {
    grid.lines(x=c(.065,.102),y=c(.185,.185),gp=gpar(col="#C3AC7C",lwd=1.5))
    txt("Motorways",.113,.185,8.5,"#BBCBC4")
    grid.lines(x=c(.270,.307),y=c(.185,.185),gp=gpar(col="#7C8B92",lwd=1))
    txt("Trunk roads",.318,.185,8.5,"#BBCBC4")
  }
  txt("MAPPED LOGISTICS DENSITY",.065,.164,9,"#ACCEC6",face="bold")
  pal <- scales::gradient_n_pal(palette,values=colour_values)
  cols <- pal(seq(0,1,length.out=300))
  for(k in seq_len(300)) grid.rect(x=.065+(k-.5)*.32/300,y=.145,width=.32/300+.0002,
    height=.009,gp=gpar(fill=cols[k],col=NA))
  breaks <- pretty(c(0,limit),n=3)
  breaks <- unique(c(breaks[breaks>=0 & breaks<limit*.95],limit))
  for(b in breaks) txt(paste0(if(b==limit) "≥" else "",format(signif(b,2),trim=TRUE)),
    .065+sqrt(b/limit)*.32,.128,8,"#A9C7BE",just="centre")
  txt(sprintf("Objects / km² · %s km Gaussian KDE",kde_km),.065,.108,8.5,"#6F9898")
  if(roads_version) {
    txt(format(nrow(points),big.mark=",",trim=TRUE),.53,.154,30,"#4EE4D0",face="bold")
    txt("MAPPED OBJECTS",.53,.123,8.5,"#92B9B0")
    txt(format(analysis$dbscan$clusters,big.mark=",",trim=TRUE),.77,.154,30,"#E5FFF7",face="bold")
    txt("DENSITY CLUSTERS",.77,.123,8.5,"#92B9B0")
    txt("Roads show mapped routes, not measured freight flows. Dots and glow locate mapped storage features.",.065,.082,9,"#A7C6BC")
    txt("Includes small storage buildings. Logistics activity is not verified; density does not measure freight volume.",.065,.061,8,"#6F9898")
    txt("© OpenStreetMap contributors · Geofabrik extract: 03 Nov 2026 · ODbL 1.0 · openstreetmap.org/copyright",.065,.035,8,"#6F9898")
    txt("MAINLAND SPAIN  /  ETRS89–LAEA",.935,.035,8,"#6F9898",just="right")
  } else {
    txt(format(nrow(points),big.mark=",",trim=TRUE),.75,.154,30,"#4EE4D0",face="bold",just="centre")
    txt("MAPPED OBJECTS",.75,.123,8.5,"#92B9B0",just="centre")
    txt("OSM filters: warehouses, logistics and trucking.",.065,.091,10,"#A7C6BC")
    txt("© OpenStreetMap contributors · Geofabrik · 03 Nov 2026",.065,.043,8,"#6F9898")
    txt("ODbL 1.0 · openstreetmap.org/copyright",.065,.026,8,"#6F9898")
    txt("#30DayMapChallenge 2026",.935,.053,9,"#9EC5BD",just="right")
    txt("Day 4 — Clusters",.935,.036,9,"#9EC5BD",just="right")
    txt("@mappedbyfer",.935,.019,9,"#9EC5BD",face="bold",just="right")
  }
}
render(file.path(out_dir,paste0(output_stem,"-social.png")),2400,2700,200)
render(file.path(out_dir,paste0(output_stem,"-portfolio.png")),4800,5400,400)
shown_labels <- if(roads_version) labels else labels[FALSE,]
write.csv(shown_labels,file.path(out_dir,paste0("label-anchors",suffix,".csv")),row.names=FALSE)
write_json_pretty(list(title=map_title,point_count=nrow(points),
  colour_transform="sqrt",palette=palette,colour_values=colour_values,
  density_cap=limit,cap_quantile=.999,legend_end_marked_as_greater_or_equal=TRUE,
  roads_variant=roads_version,road_classes=as.list(table(roads$highway)),
  road_style=if(roads_version) "prominent motorway/trunk overlay" else "subtle original context: #73818A, alpha 0.12, linewidth 0.10",
  road_interpretation="Mapped motorway/trunk geometry only; no freight flows or cluster connectivity analysis",
  kde_sigma_m=kde_km*1000,colour_reference_sigma_m=8000,
  labels=shown_labels[,c("cluster_id","label","objects","city_distance_km")],
  cluster_count_displayed=roads_version,subtitle_displayed=roads_version,
  challenge_position=if(roads_version) "header" else "bottom right",
  data_attribution_position="bottom left",x_handle=if(roads_version) NULL else "@mappedbyfer",
  osm_filter_note="OSM filters: warehouses, logistics and trucking.",
  crs_epsg=crs_analysis,dimensions_social=c(2400,2700),dimensions_portfolio=c(4800,5400)),paste0("render-info",suffix,".json"))
