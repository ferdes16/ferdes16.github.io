args_all <- commandArgs(FALSE)
entry <- sub("^--file=", "", args_all[grepl("^--file=",args_all)][1])
root <- normalizePath(file.path(dirname(entry),".."),mustWork=TRUE)
local_library <- file.path(root,"data/library")
.libPaths(c(local_library,.libPaths()))
suppressPackageStartupMessages({library(sf);library(dplyr);library(ggplot2);library(jsonlite)})
crs_analysis <- 3035L # ETRS89 / LAEA Europe: metres; equal-area analysis.
bg <- "#08131B"
raw_dir <- file.path(root,"data/raw")
processed_dir <- file.path(root,"data/processed")
out_dir <- file.path(root,"output")
for(p in c(raw_dir,processed_dir,out_dir,local_library)) dir.create(p,recursive=TRUE,showWarnings=FALSE)
write_json_pretty <- function(x,name) write_json(x,file.path(out_dir,name),pretty=TRUE,auto_unbox=TRUE,na="null",digits=8)
save_gpkg <- function(x,name,layer) st_write(x,file.path(processed_dir,name),layer=layer,delete_layer=TRUE,quiet=TRUE)
fetch <- function(url,dest) {
  if(file.exists(dest)) return(invisible(dest))
  part <- paste0(dest,".part")
  # curl handles redirects, retries and resuming large extracts; called from R.
  status <- system2("curl",c("--fail","--location","--silent","--show-error",
    "--retry","3","--continue-at","-","--output",shQuote(part),shQuote(url)))
  if(status!=0) stop("Download incomplete: ",url)
  stopifnot(file.rename(part,dest))
  invisible(dest)
}
