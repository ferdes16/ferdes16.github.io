source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
pbf <- file.path(raw_dir,"spain-261103.osm.pbf")
stopifnot(file.exists(pbf))
dest <- file.path(raw_dir,"osm-logistics-and-motorways.gpkg")
condition <- paste0("building = 'warehouse' OR building_use = 'warehouse' OR ",
  "industrial IN ('warehouse','logistics','trucking') OR highway IN ('motorway','trunk')")
if(!file.exists(dest)) {
  temporary <- file.path(raw_dir,"osm-extract-incomplete.gpkg")
  ok <- sf::gdal_utils("vectortranslate",source=pbf,destination=temporary,
    options=c("-f","GPKG","-oo",paste0("CONFIG_FILE=",file.path(root,"scripts/osmconf.ini")),
      "-where",condition,"-lco","SPATIAL_INDEX=YES","points","lines","multipolygons"),
    config_options=c(OSM_MAX_TMPFILE_SIZE="768",OSM_COMPRESS_NODES="YES",CPL_TMPDIR=raw_dir),quiet=FALSE)
  stopifnot(ok,file.rename(temporary,dest))
}
layers <- st_layers(dest)
print(layers)
write_json_pretty(list(source=basename(pbf),filter=condition,layers=layers$name,
  extraction="GDAL OSM driver, single PBF pass; all_tags preserved; no general landuse=industrial inclusion"),"extraction.json")
