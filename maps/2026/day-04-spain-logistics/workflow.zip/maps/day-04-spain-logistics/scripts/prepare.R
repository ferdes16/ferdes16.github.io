source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
countries <- st_read(file.path(raw_dir,"ne_10m_admin_0_countries/ne_10m_admin_0_countries.shp"),quiet=TRUE) |>
  st_make_valid() |> st_transform(crs_analysis)
spain <- countries |> filter(ADMIN=="Spain")
parts <- suppressWarnings(st_cast(st_geometry(spain),"POLYGON"))
mainland <- st_sf(name="Mainland Spain",geometry=parts[which.max(as.numeric(st_area(parts)))])
save_gpkg(mainland,"context.gpkg","mainland")
context <- st_crop(countries,st_bbox(st_buffer(mainland,80000)))
save_gpkg(select(context,ADMIN),"context.gpkg","countries")
cities <- st_read(file.path(raw_dir,"ne_10m_populated_places_simple/ne_10m_populated_places_simple.shp"),quiet=TRUE) |>
  filter(adm0name=="Spain") |> st_transform(crs_analysis)
cities <- cities[lengths(st_intersects(cities,mainland))>0,]
save_gpkg(select(cities,name,pop_max),"context.gpkg","cities")

input <- file.path(raw_dir,"osm-logistics-and-motorways.gpkg")
logistics_match <- function(d) {
  d$building %in% "warehouse" | d$building_use %in% "warehouse" |
    d$industrial %in% c("warehouse","logistics","trucking")
}
features <- bind_rows(lapply(c("multipolygons","points","lines"),function(layer) {
  d <- st_read(input,layer=layer,quiet=TRUE)
  for(n in c("building","building_use","industrial","highway","landuse","name","all_tags","disused","abandoned"))
    if(!n %in% names(d)) d[[n]] <- NA_character_
  if(!"osm_way_id" %in% names(d)) d$osm_way_id <- NA_character_
  d$osm_type <- if(layer=="points") "node" else if(layer=="lines") "way" else
    ifelse(!is.na(d$osm_way_id) & nzchar(d$osm_way_id),"way","relation")
  d$source_id <- ifelse(d$osm_type=="way" & layer=="multipolygons",d$osm_way_id,d$osm_id)
  d$feature_id <- paste(d$osm_type,d$source_id,sep="/")
  d$source_layer <- layer
  d <- d[logistics_match(d),]
  select(d,feature_id,osm_type,source_id,source_layer,name,building,building_use,industrial,
    landuse,disused,abandoned,all_tags)
})) |> st_transform(crs_analysis)
initial_n <- nrow(features)
stopifnot(initial_n>0,all(logistics_match(features)),!anyNA(features$feature_id))
audit <- list()
record_removal <- function(d,reason,parent=NA_character_) {
  if(nrow(d)==0) return(invisible(NULL))
  x <- st_drop_geometry(d) |> select(feature_id,source_layer,name,building,building_use,industrial)
  x$reason <- reason; x$represented_by <- parent
  audit[[length(audit)+1]] <<- x
}
# Keep source geometries and tags even for items excluded from the point sample.
features$valid_before <- st_is_valid(features)
invalid_n <- sum(!features$valid_before | is.na(features$valid_before))
features <- st_make_valid(features)
empty <- st_is_empty(features)
record_removal(features[empty,],"empty geometry after repair")
features <- features[!empty,]
active <- !features$disused %in% c("yes","true","1") & !features$abandoned %in% c("yes","true","1")
record_removal(features[!active,],"explicitly disused or abandoned")
features <- features[active,]
points <- suppressWarnings(st_point_on_surface(features))
inside <- lengths(st_intersects(points,mainland))>0
record_removal(features[!inside,],"outside mainland cartographic land mask")
features <- features[inside,]
features$is_area <- as.character(st_geometry_type(features)) %in% c("POLYGON","MULTIPOLYGON")
features$warehouse_tag <- features$building %in% "warehouse" | features$building_use %in% "warehouse" |
  features$industrial %in% "warehouse"
features$category <- ifelse(features$warehouse_tag,"Warehouse","Other logistics / trucking")
features$footprint_area_m2 <- ifelse(features$is_area,as.numeric(st_area(features)),NA_real_)
features$building_footprint <- features$is_area & (!is.na(features$building) | !is.na(features$building_use))
# Prefer a footprint to a repeated line/node with the same OSM element ID.
features <- features |> arrange(desc(is_area),desc(osm_type=="relation"),feature_id)
same_id <- duplicated(features$feature_id)
record_removal(features[same_id,],"duplicate OSM type/id")
features <- features[!same_id,]
equals <- st_equals(features)
same_geometry <- vapply(seq_along(equals),function(i) any(equals[[i]]<i),logical(1))
record_removal(features[same_geometry,],"topologically equal geometry")
features <- features[!same_geometry,]

# One representative point per mapped footprint. A separately tagged node inside
# an already-selected warehouse footprint is retained as metadata, not counted twice.
node_i <- which(features$source_layer=="points")
building_i <- which(features$building_footprint)
remove <- integer()
if(length(node_i) && length(building_i)) {
  hits <- st_intersects(features[node_i,],features[building_i,])
  for(j in which(lengths(hits)>0)) {
    parent <- features$feature_id[building_i[hits[[j]][1]]]
    record_removal(features[node_i[j],],"node represented by selected building footprint",parent)
    remove <- c(remove,node_i[j])
  }
}
if(length(remove)) features <- features[-unique(remove),]

# Broader logistics-site polygons often surround individually mapped warehouses.
# Keep their geometries for inspection but exclude such enclosing sites from KDE
# and DBSCAN when their buildings are already part of the sample.
points <- suppressWarnings(st_point_on_surface(features))
features$analysis_included <- TRUE
features$analysis_reason <- "representative mapped object"
sites <- which(features$is_area & !features$building_footprint)
buildings <- which(features$building_footprint)
if(length(sites) && length(buildings)) {
  hits <- st_intersects(features[sites,],points[buildings,])
  site_parents <- sites[lengths(hits)>0]
  features$analysis_included[site_parents] <- FALSE
  features$analysis_reason[site_parents] <- "enclosing site; mapped buildings counted instead"
}
points <- suppressWarnings(st_point_on_surface(features[features$analysis_included,]))
# Coincident representative locations are collapsed only for the point analysis.
# Keep every underlying footprint/site in the geometry layer and list the IDs.
xy <- st_coordinates(points)
key <- paste(sprintf("%.3f",xy[,1]),sprintf("%.3f",xy[,2]))
same_point <- duplicated(key)
record_removal(points[same_point,],"coincident representative point at millimetre precision")
points <- points[!same_point,]
stopifnot(!anyDuplicated(points$feature_id),all(st_is_valid(features)),
  !any(st_is_empty(points)),all(logistics_match(points)),st_crs(points)$epsg==crs_analysis)
save_gpkg(features,"logistics.gpkg","source_geometries")
save_gpkg(points,"logistics.gpkg","facility_points")
saveRDS(points,file.path(processed_dir,"facility-points.rds"))
write.csv(bind_rows(audit),file.path(out_dir,"cleaning-audit.csv"),row.names=FALSE)

roads <- st_read(input,layer="lines",quiet=TRUE) |> filter(highway %in% c("motorway","trunk")) |>
  st_transform(crs_analysis) |> st_make_valid()
roads <- roads[lengths(st_intersects(roads,mainland))>0,] |> st_simplify(dTolerance=120)
save_gpkg(select(roads,osm_id,name,highway),"context.gpkg","major_roads")
summary <- st_drop_geometry(points) |> count(category,name="mapped_objects")
write.csv(summary,file.path(out_dir,"category-counts.csv"),row.names=FALSE)
tag_counts <- data.frame(tag=c("building=warehouse","building:use=warehouse","industrial=warehouse",
  "industrial=logistics","industrial=trucking"),objects=c(sum(points$building %in% "warehouse"),
  sum(points$building_use %in% "warehouse"),sum(points$industrial %in% "warehouse"),
  sum(points$industrial %in% "logistics"),sum(points$industrial %in% "trucking")))
write.csv(tag_counts,file.path(out_dir,"matching-tag-counts.csv"),row.names=FALSE)
write_json_pretty(list(initial_tagged_objects=initial_n,invalid_before_repair=invalid_n,
  retained_geometry_records=nrow(features),analysis_points=nrow(points),
  broader_enclosing_sites=sum(!features$analysis_included),coincident_point_rows=sum(same_point),
  final_invalid_geometries=sum(!st_is_valid(features)),duplicates_by_type_id=sum(duplicated(points$feature_id)),
  categories=summary,context_road_features=nrow(roads),crs_epsg=crs_analysis,
  geometry_types=as.list(table(as.character(st_geometry_type(features)))),
  mask="Largest Natural Earth 10m Spain polygon; exact representative-point inclusion",
  counting_unit="One selected mapped building/site/point, not necessarily one business or independent facility"),"validation.json")

# Required first-stage point map, before clustering or density calculation.
p <- ggplot() + geom_sf(data=mainland,fill="#0D1E28",colour="#263844",linewidth=.25) +
  geom_sf(data=points,colour="#4EE4D0",size=.13,alpha=.6) +
  coord_sf(datum=NA) + labs(title="WHERE SPAIN MOVES",subtitle="Raw logistics-related OSM objects · mainland Spain",
    caption=paste(format(nrow(points),big.mark=","),"representative points · © OpenStreetMap contributors · ODbL 1.0")) +
  theme_void(base_family="Helvetica") + theme(plot.background=element_rect(fill=bg,colour=NA),
    text=element_text(colour="#D8EEE8"),plot.title=element_text(size=24,face="bold"),
    plot.margin=margin(25,25,20,25))
ggsave(file.path(out_dir,"01-raw-logistics-points.png"),p,width=10,height=9,dpi=180,device=ragg::agg_png,bg=bg)
print(summary)
