# Reference names from the same OSM snapshot, rather than sparse global cities.
source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
dest <- file.path(raw_dir,"osm-settlements.gpkg")
if(!file.exists(dest)) {
  temp <- file.path(raw_dir,"osm-settlements-incomplete.gpkg")
  ok <- sf::gdal_utils("vectortranslate",source=file.path(raw_dir,"spain-261103.osm.pbf"),
    destination=temp,options=c("-f","GPKG","-oo",paste0("CONFIG_FILE=",system.file("osmconf.ini",package="osmextract")),
      "-where","place IN ('city','town')","points"),
    config_options=c(OSM_MAX_TMPFILE_SIZE="768",OSM_COMPRESS_NODES="YES",CPL_TMPDIR=raw_dir),quiet=FALSE)
  stopifnot(ok,file.rename(temp,dest))
}
towns <- st_read(dest,layer="points",quiet=TRUE) |> st_transform(crs_analysis)
mainland <- st_read(file.path(processed_dir,"context.gpkg"),layer="mainland",quiet=TRUE)
towns <- towns[lengths(st_intersects(towns,mainland))>0 & !is.na(towns$name),]
towns$reference_source <- "OpenStreetMap place=city/town, same PBF snapshot"
save_gpkg(select(towns,osm_id,name,place,reference_source),"context.gpkg","osm_towns")
message(nrow(towns)," mainland city/town references cached from OSM.")
