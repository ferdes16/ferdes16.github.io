# Day 05 — Senses: Sight | How far can you see? — Eixample

**Title:** HOW FAR CAN YOU SEE?

**Legend label:** VISIBLE AREA (m²)

The poster has no subtitle. A minimal two-tone 50 m scale bar sits immediately
below the map on the right, at the same height as the former left-hand bar.
The former “OSM base” technical footer line is omitted. Data
provenance remains documented here and in `output/sources.json`; OSM contributor
and licence attribution remains on the poster.

**Status:** final dark poster exported and visually checked. All 8,833 isovists
and coverage/export checks passed. Cell outlines were subsequently removed at
the owner's request; the quantitative measurements are unchanged.
The owner selected this version and explicitly approved GitHub and portfolio
publication on **5 November 2026**.
Portfolio: [HOW FAR CAN YOU SEE?](https://mappedbyfer.com/maps/2026/day-05-geometry-of-sight-dark/).

The owner requested a dark version of the **Eixample** map, real visibility
calculations in previously unfilled street/plaza areas, and a **100 m expansion
on every side**. This independent project preserves the earlier light posters
and animation. It does not publish or push anything automatically.

## What changes

- **700 × 700 m**, centred on the same original easting/northing. The original
  500 m square gains 100 m at its north, south, east and west edges.
- Dark charcoal background, slate buildings, and blue-grey → teal → mint → gold
  visible-area colours. Streets remain broad surfaces between the facades.
- The former 35 m lateral display cap is removed.
- A genuine **5 m two-dimensional sampling grid** covers modelled street and
  open-space surfaces. Every clipped cell component has its own observer and
  calculated isovist, including positions far from street axes and in plaza
  interiors. Existing axis values are not stretched into those cells.

## Real data and scope

Source: © [OpenStreetMap contributors](https://www.openstreetmap.org/copyright),
under [ODbL 1.0](https://opendatacommons.org/licenses/odbl/1-0/), from the original
Eixample Overpass download. Source snapshot reported by the provider:
**15 July 2026, 15:22:01 UTC**; original acquisition: **4 November 2026**. This
variant reuses an independent raw cache rather than making another API request.

The full cached source covers west 2.154°, south 41.386°, east 2.172°, north
41.400° in WGS84. The raw XML checksum is
`8312207a5739684cc1e6f68a7cbc7bf1`. The new geometry is prepared again from the
complete source, including additional buildings outside the former obstacle
envelope. All 150 m viewing disks in the enlarged square are checked to remain
inside the downloaded source coverage.

CRS: **ETRS89 / UTM zone 31N, EPSG:25831**, in metres. Expanded display extent:
eastings **429660–430360**, northings **4582320–4583020**. This is a square in
projected coordinates; camera extent and scale remain fixed in the static PNG.

`data/raw/` contains the independent original XML, parsed OSM cache and original
source metadata. `output/sources.json` preserves provider and licence details.
No previous project is imported at runtime or overwritten. A small, losslessly
compressed copy of the exact original XML is included in `source/`, with its
ODbL attribution and source manifest. The large derived datasets, native build
caches and analysis checkpoints remain local under ignored `data/`.

## Buildings, streets and open-space coverage

Building ways/multipolygons are checked, repaired where necessary, deduplicated
and unioned without simplifying their real outlines. Explicit non-building,
roof, construction, ruin and underground records are excluded. All courtyard
rings are retained as geometric boundaries.

The same surface street classes as the selected light map are retained, with
explicit private/no access, prohibited foot access, indoor, tunnel, underground
and bridge ways excluded. Separately mapped pedestrian **area** polygons with
public/permissive access are also inspected and retained as support for plaza
sampling. Geometry does not independently establish current public access.

The analysis domain is the study square minus the building obstacles and a
**0.6 m facade margin**. Only open components touching the selected street
network or explicitly mapped pedestrian areas are retained. Isolated courtyard
components are excluded. Unlike the previous display mask, there is **no 35 m
distance-to-axis cap**. This allows full coverage of broad street spaces and
plaza interiors.

The domain is split by a regular **5 × 5 m square grid**. Intersections with the
domain are split into their separate polygon components; each receives an
interior representative point using `st_point_on_surface`. Full square cells
therefore have centred observers, while partial boundary cells have observers
inside their own remaining free-space component. A cell split by a wall does
not inherit a measurement from the other side of the wall.

The source-derived open-space domain is a **modelled sampling surface**, not a
surveyed pavement/accessibility inventory. Sampling does not confirm that every
point is physically walkable or currently accessible.

## Genuine visibility calculations

Every observer casts rays through 360° against the actual opaque building
boundaries, stopping at the **first intersection** or **150 m**. Directions
include a **0.25°** regular sweep plus every nearby obstacle vertex bearing and
**±10⁻⁷ radian** offsets at those bearings. A 0.00001 m numerical setback avoids
roundoff extending endpoints into a facade. The metric is the projected area of
the resulting visibility polygon in **m²**. Circular buffers do not replace
isovists, and values are not inferred from distance to a street or junction.

R controls acquisition, geometry, sampling, validation and plotting. A small
Rcpp helper accelerates the numerical ray/segment intersections. `Rcpp` was
already installed; no new dependency was added. Its angular buckets are only
conservative candidate indexes: the rays retain their exact directions, and
each candidate is checked with the original exact intersection equations.
All building rings remain in the underlying segment cache.

Before full analysis, the indexed engine is checked against the original
all-segment R implementation at ten real positions, including a point far from
the axes and points in previously unfilled areas. Maximum endpoint and polygon
differences are recorded in `engine-validation.json`. The measured numerical
differences were below 10⁻⁹ m for endpoints and 10⁻¹⁰ m² for symmetric area.

Every final polygon must be valid, contain its observer, have positive area
below π × 150², and overlap building interiors by less than 10⁻⁶ m². Independently
sampled complete sightline segments at every observer are also intersected with
building obstacles using GEOS. Checks preserve courtyard boundaries and verify
that the coloured grid cells cover the entire selected domain, including the
formerly unfilled parts, without crossing building interiors.

## Geometry results

| Measure | Result |
|---|---:|
| Source building records in the new obstacle envelope | 1,182 |
| Invalid source geometries repaired | 2 |
| Merged obstacle polygons | 86 |
| Selected source street ways | 111 |
| Actual 2D observers | 8,833 |
| Modelled street/open-space area | 179,535 m² |
| Area beyond the old 35 m lateral cap | 12,102 m² |
| Observers in those previously unfilled areas | 671 |
| Observers more than 15 m from street axes | 1,276 |
| Observers in explicitly mapped pedestrian areas | 423 |
| Isolated open components excluded | 354 |

The visibility measurements, numerical errors, coverage and final export checks
are recorded in `analysis-validation.json` and `export-validation.json`.
`visibility-samples.csv` preserves coordinates, cell areas, actual visible areas
and flags identifying the additional observation types. The processed GeoPackage
retains all cells, observers, isovists, source geometry and the analysis domain.

## Design and outputs

Background `#0A151D`, buildings `#21313B`, and an ordered blue-grey/teal/mint/gold
palette. The **linear 0–30,000 m²** metric range is retained for comparison with
the earlier map. Values above the display limit remain uncapped in the data;
the upper legend is marked **≥30,000** when needed. Colours represent the actual
isovist at each grid-cell observer, without averaging measurements or copying an
axis value into the middle of a plaza. Analytical sampling resolution is 5 m.

For a clean **fill-only** image, the existing cell values are rasterised once at
0.5 m for display, then rendered as a single image with graphical bilinear
interpolation. There are no individual cell outlines or vector antialiasing
seams. Buildings are drawn above the surface. This improves the export's
appearance; it does not create new observations, alter raw values or imply
0.5 m analytical accuracy.

- [High-resolution PNG](output/the-geometry-of-sight-eixample-dark-portfolio.png):
  **3000 × 3600 px**.
- [Preview PNG](output/the-geometry-of-sight-eixample-dark-preview.png):
  **1500 × 1800 px**.
- `data/processed/geometry-of-sight.gpkg`: source/context, sampling domain,
  observation cells, observations and isovists.
- `data/processed/visibility.rds`: processed metric/display cache.
- `output/geometry-validation.json`, `engine-validation.json`,
  `engine-regression-check.csv`, `analysis-validation.json`, `render-info.json`,
  `export-validation.json`, `visibility-samples.csv`, `session-info.txt`.

## Reproduce

Dependencies: R, sf/GDAL/GEOS/PROJ, osmdata, dplyr, jsonlite, ggplot2, scales, png, terra, ragg
and Rcpp with a C++ compiler. Existing dependencies on the project machine were
used. Typography: DIN Condensed and Avenir Next; substitute available fonts and
inspect layout on other systems. Compiled caches and spatial datasets remain
under the repository-ignored `data/` directory.

`00-restore-source.R` restores the bundled XML, verifies its original MD5 and
parses it with `osmdata::osmdata_sf` when the local RDS is absent. This also
works from a fresh checkout without any live API request. A different live
extract could contain different geometry.

From the repository root:

```sh
Rscript maps/2026/day-05-geometry-of-sight-dark/scripts/00-restore-source.R
Rscript maps/2026/day-05-geometry-of-sight-dark/scripts/01-prepare.R
Rscript maps/2026/day-05-geometry-of-sight-dark/scripts/02-engine-check.R
Rscript maps/2026/day-05-geometry-of-sight-dark/scripts/03-analyse.R
Rscript maps/2026/day-05-geometry-of-sight-dark/scripts/04-render.R
Rscript maps/2026/day-05-geometry-of-sight-dark/scripts/05-verify.R
```

Analysis checkpoints prevent losing all completed work if a long calculation is
interrupted. Raw and processed datasets are not committed automatically. This
variant changes only Day 5 and leaves the selected light PNGs intact.

## Limitations

The model is horizontal, planar and 360°, rather than a forward-facing visual
cone. Building heights, eye height, terrain, vegetation, vehicles, street
furniture, transparent openings and temporary works are not modelled. Public
space, access, gaps and obstacles follow source geometry/tags rather than an
independent field survey. Visibility depends on the source geometry, observer
position, viewing distance and grid resolution; it does not directly measure
human perception.
