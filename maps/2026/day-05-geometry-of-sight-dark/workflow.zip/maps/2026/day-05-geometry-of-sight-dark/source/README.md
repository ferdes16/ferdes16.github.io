# Exact OSM source snapshot

`eixample-2026-07-15.osm.gz` is a losslessly compressed copy of the original
Overpass XML used for the selected poster. Uncompressed size: 6,986,648 bytes;
MD5: `8312207a5739684cc1e6f68a7cbc7bf1`. The provider reported an OSM base of
15 July 2026, 15:22:01 UTC; the original acquisition was 4 November 2026.
`sources.json` records the endpoint, bbox and original checksum.

Data © OpenStreetMap contributors, under the Open Database License (ODbL) 1.0:
https://opendatacommons.org/licenses/odbl/1-0/
Attribution and copyright: https://www.openstreetmap.org/copyright

The source query selected buildings or highways and recursively included member
nodes/ways within and around the bbox 2.154,41.386,2.172,41.400. The compressed
snapshot contains no simulated geometry or calculated visibility values.

Run `scripts/00-restore-source.R` from the repository root as documented in the
main README to restore the local raw XML and parsed R cache. Derived databases
and compiled/rendering caches are regenerated locally and are not included here.
