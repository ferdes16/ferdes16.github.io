source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
source(file.path(project_dir,"scripts/isovist-engine.R"))
stopifnot(isTRUE(read_json(file.path(output_dir,"engine-validation.json"))$passed))
db <- file.path(processed_dir,"geometry-of-sight.gpkg")
obstacles <- st_read(db,"obstacles",quiet=TRUE)
samples <- st_read(db,"samples",quiet=TRUE)
cells <- st_read(db,"cells",quiet=TRUE)
metric_columns <- c("visible_area_m2","ray_count","building_overlap_m2",
                    "blocked_sightline_length_m","indexed_segment_tests")
samples <- select(samples,-any_of(metric_columns))
cells <- select(cells,-any_of(metric_columns))
xy <- st_coordinates(samples)
cache <- prepare_isovist_engine(obstacles)
union_obstacles <- st_union(obstacles)
stopifnot(abs(sum(sqrt(rowSums((cache$segments[,1:2]-cache$segments[,3:4])^2))) -
  sum(as.numeric(st_length(st_boundary(obstacles)))))<1e-6)
n <- nrow(samples)
geometries <- vector("list",n); metrics <- vector("list",n)
checkpoint <- file.path(processed_dir,"isovist-checkpoint.rds")
input_key <- unname(tools::md5sum(file.path(project_dir,c("data/raw/osmdata.rds",
  "scripts/01-prepare.R","scripts/common.R","scripts/isovist-engine.R",
  "scripts/ray-casting.cpp","scripts/03-analyse.R"))))
start_i <- 1L
if(file.exists(checkpoint)) {
  saved <- readRDS(checkpoint)
  if(identical(saved$xy,xy) && identical(saved$input_key,input_key)) {
    geometries <- saved$geometries;metrics <- saved$metrics;start_i <- saved$completed+1L
  } else message("Inputs or engine changed; starting a fresh validated analysis.")
}
started <- Sys.time()
if(start_i<=n)for(i in start_i:n) {
  result <- cast_isovist(xy[i,],obstacles,cache=cache)
  overlap <- suppressWarnings(st_intersection(result$geometry,union_obstacles))
  overlap_area <- if(length(overlap))sum(as.numeric(st_area(overlap))) else 0
  stopifnot(overlap_area<1e-6,result$max_endpoint_distance<=150,
    lengths(st_within(st_geometry(samples[i,]),result$geometry))==1)
  # Independent GEOS obstruction checks in addition to polygon overlap tests.
  ends <- result$endpoints[seq(1,nrow(result$endpoints),by=97),,drop=FALSE]
  rays <- st_sfc(lapply(seq_len(nrow(ends)),function(j)st_linestring(rbind(xy[i,],ends[j,]))),crs=analysis_crs)
  blocked <- suppressWarnings(st_intersection(rays,union_obstacles))
  blocked_length <- if(length(blocked))sum(as.numeric(st_length(blocked))) else 0
  stopifnot(blocked_length<1e-6)
  geometries[[i]] <- result$geometry[[1]]
  metrics[[i]] <- data.frame(sample_id=samples$sample_id[i],visible_area_m2=as.numeric(st_area(result$geometry)),
    ray_count=result$ray_count,building_overlap_m2=overlap_area,blocked_sightline_length_m=blocked_length,
    indexed_segment_tests=result$segment_tests)
  if(i%%250==0)message("Checked ",i,"/",n," genuine area isovists (",round(as.numeric(difftime(Sys.time(),started,units="secs")))," s).")
  if(i%%1000==0)saveRDS(list(input_key=input_key,xy=xy,geometries=geometries,metrics=metrics,completed=i),checkpoint,compress=FALSE)
}
if(start_i<=n)saveRDS(list(input_key=input_key,xy=xy,geometries=geometries,
  metrics=metrics,completed=n),checkpoint,compress=FALSE)
metrics <- bind_rows(metrics)
isovists <- st_sf(metrics,geometry=st_sfc(geometries,crs=analysis_crs))
samples <- left_join(samples,metrics,by="sample_id")
cells <- left_join(cells,metrics,by="sample_id")
stopifnot(all(st_is_valid(isovists)),all(metrics$visible_area_m2>0),all(metrics$visible_area_m2<pi*150^2))
for(layer in c("samples","cells","isovists"))write_layer(get(layer),layer)
saveRDS(list(samples=samples,cells=cells),file.path(processed_dir,"visibility.rds"))
write.csv(cbind(st_drop_geometry(samples),x=xy[,1],y=xy[,2]),file.path(output_dir,"visibility-samples.csv"),row.names=FALSE)
write_report(list(passed=TRUE,sample_count=n,area_m2_range=range(metrics$visible_area_m2),
  area_m2_quantiles=quantile(metrics$visible_area_m2,c(0,.25,.5,.75,1)),
  area_weighted_mean_visible_area_m2=weighted.mean(metrics$visible_area_m2,cells$cell_area_m2),
  observations_in_previously_unfilled_areas=sum(samples$in_previously_unfilled_area),
  observations_over_15m_from_axis=sum(samples$distance_to_axis_m>15),
  ray_count_range=range(metrics$ray_count),max_building_overlap_m2=max(metrics$building_overlap_m2),
  max_tested_sightline_length_inside_buildings_m=max(metrics$blocked_sightline_length_m),
  all_observers_outside_buildings=TRUE,all_obstacle_rings_preserved=TRUE,
  radius_m=150,regular_grid_m=5,angular_step_degrees=.25,vertex_offset_radians=1e-7,
  elapsed_seconds=as.numeric(difftime(Sys.time(),started,units="secs"))),"analysis-validation.json")
message("All street-and-plaza isovists passed obstruction checks.")
