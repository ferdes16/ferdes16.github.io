source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
stopifnot(isTRUE(read_json(file.path(output_dir,"analysis-validation.json"))$passed))
db <- file.path(processed_dir,"geometry-of-sight.gpkg")
samples <- st_read(db,"samples",quiet=TRUE)
cells <- st_read(db,"cells",quiet=TRUE)
obstacles <- st_read(db,"obstacles",quiet=TRUE)
domain <- st_read(db,"domain",quiet=TRUE)
new_open_space <- st_read(db,"new_open_space",quiet=TRUE)
stopifnot(all(lengths(st_intersects(samples,obstacles))==0),all(st_is_valid(cells)),
  nrow(cells)==nrow(samples),all(cells$visible_area_m2==samples$visible_area_m2),
  all(samples$visible_area_m2>0),sum(samples$in_previously_unfilled_area)>0,
  sum(samples$distance_to_axis_m>15)>0)
overlap <- suppressWarnings(st_intersection(st_geometry(cells),st_union(obstacles)))
overlap_area <- if(length(overlap))sum(as.numeric(st_area(overlap))) else 0
uncovered <- suppressWarnings(st_difference(st_geometry(domain),st_union(cells)))
uncovered_area <- if(length(uncovered))sum(as.numeric(st_area(uncovered))) else 0
gap_uncovered <- suppressWarnings(st_difference(st_geometry(new_open_space),st_union(cells)))
gap_area <- if(length(gap_uncovered))sum(as.numeric(st_area(gap_uncovered))) else 0
stopifnot(overlap_area<1e-6,uncovered_area<.001,gap_area<.001)
files <- file.path(output_dir,paste0("the-geometry-of-sight-eixample-dark-",c("portfolio","preview"),".png"))
dimensions <- list(c(3600,3000),c(1800,1500))
for(i in seq_along(files)) {
  pixels <- png::readPNG(files[i],native=TRUE)
  stopifnot(all(dim(pixels)[1:2]==dimensions[[i]]));rm(pixels)
}
for(f in list.files(file.path(project_dir,"scripts"),pattern="[.]R$",full.names=TRUE))parse(f)
write_report(list(passed=TRUE,all_colours_from_real_cell_isovists=TRUE,
  isovist_observer_count=nrow(samples),building_overlap_m2=overlap_area,
  uncovered_street_and_open_space_m2=uncovered_area,
  uncovered_previously_blank_area_m2=gap_area,full_150m_obstacle_margin=TRUE,
  image_dimensions=list(portfolio=c(3000,3600),preview=c(1500,1800)),
  png_md5=as.list(setNames(unname(tools::md5sum(files)),basename(files)))),"export-validation.json")
message("Dark PNGs and complete sampled coverage of streets/open areas verified.")
