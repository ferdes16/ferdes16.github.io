source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
manifest <- read_json(file.path(project_dir,"source/sources.json"))
raw_file <- file.path(raw_dir,"eixample.osm")
if(!file.exists(raw_file)) {
  connection <- gzfile(file.path(project_dir,"source/eixample-2026-07-15.osm.gz"),"rb")
  bytes <- readBin(connection,"raw",n=manifest$raw_bytes+1)
  close(connection)
  stopifnot(length(bytes)==manifest$raw_bytes)
  writeBin(bytes,raw_file)
}
stopifnot(unname(tools::md5sum(raw_file))==manifest$raw_md5)
metadata_file <- file.path(raw_dir,"sources-original.json")
if(!file.exists(metadata_file))stopifnot(file.copy(file.path(project_dir,"source/sources.json"),metadata_file))
parsed_file <- file.path(raw_dir,"osmdata.rds")
if(!file.exists(parsed_file)) {
  stopifnot(requireNamespace("osmdata",quietly=TRUE))
  saveRDS(osmdata::osmdata_sf(doc=raw_file),parsed_file)
}
message("Exact bundled OSM snapshot restored and checksum verified; no API request needed.")
