#include <Rcpp.h>
#include <vector>
#include <cmath>
#include <algorithm>
using namespace Rcpp;

// Conservative angular buckets index possible intersected segments. Actual
// rays retain their exact directions and stop at the exact first intersection.
// No ray directions, footprints, or sight distances are approximated by bins.
// [[Rcpp::export]]
List first_hits_indexed(NumericVector origin, NumericMatrix segments,
                        NumericVector angles, double radius=150.0) {
  const double pi=std::acos(-1.0), tau=2*pi, margin=1e-6;
  const int bins=1440;
  const double step=tau/bins;
  struct Edge { double ax,ay,sx,sy,numerator; };
  std::vector<Edge> edges;
  std::vector<std::vector<int>> buckets(bins);
  auto add_interval=[&](double low,double high,int id) {
    int a=std::max(0,static_cast<int>(std::floor((low-margin)/step)));
    int b=std::min(bins-1,static_cast<int>(std::floor((high+margin)/step)));
    for(int bin=a;bin<=b;++bin)buckets[bin].push_back(id);
    if(low<=margin)buckets[bins-1].push_back(id);
    if(high>=tau-margin)buckets[0].push_back(id);
  };
  for(int i=0;i<segments.nrow();++i) {
    double ax=segments(i,0)-origin[0],ay=segments(i,1)-origin[1];
    double bx=segments(i,2)-origin[0],by=segments(i,3)-origin[1];
    double sx=bx-ax,sy=by-ay,den=sx*sx+sy*sy;
    if(den<1e-16)continue;
    double u=std::max(0.0,std::min(1.0,-(ax*sx+ay*sy)/den));
    double px=ax+u*sx,py=ay+u*sy;
    if(px*px+py*py>(radius+.01)*(radius+.01))continue;
    int id=edges.size(); edges.push_back({ax,ay,sx,sy,ax*sy-ay*sx});
    double a=std::atan2(ay,ax); if(a<0)a+=tau;
    double b=std::atan2(by,bx); if(b<0)b+=tau;
    double low=std::min(a,b),high=std::max(a,b);
    if(high-low<=pi)add_interval(low,high,id);
    else {add_interval(0,low,id);add_interval(high,tau,id);}
  }
  NumericMatrix endpoints(angles.size(),2);
  NumericVector distances(angles.size());
  double tested=0;
  for(int k=0;k<angles.size();++k) {
    if(k%1000==0)checkUserInterrupt();
    double angle=angles[k],dx=std::cos(angle),dy=std::sin(angle),best=radius;
    int bin=std::min(bins-1,std::max(0,static_cast<int>(std::floor(angle/step))));
    for(int id:buckets[bin]) {
      const Edge &e=edges[id];
      double denominator=dx*e.sy-dy*e.sx;
      ++tested;
      if(std::abs(denominator)<=1e-12)continue;
      double fraction=(e.ax*dy-e.ay*dx)/denominator;
      if(fraction < -1e-10 || fraction > 1.0+1e-10)continue;
      double distance=e.numerator/denominator;
      if(std::isfinite(distance) && distance>=-1e-9 && distance<best)best=distance;
    }
    best=std::max(0.0,best-1e-5);
    distances[k]=best;
    endpoints(k,0)=origin[0]+best*dx;
    endpoints(k,1)=origin[1]+best*dy;
  }
  return List::create(_["endpoints"]=endpoints,_["distances"]=distances,
    _["segment_tests"]=tested,_["candidate_segments"]=static_cast<int>(edges.size()));
}
