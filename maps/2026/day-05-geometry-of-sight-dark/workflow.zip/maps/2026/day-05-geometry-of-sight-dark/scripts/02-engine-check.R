source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
source(file.path(project_dir,"scripts/isovist-engine.R"))
db <- file.path(processed_dir,"geometry-of-sight.gpkg")
obstacles <- st_read(db,"obstacles",quiet=TRUE)
samples <- st_read(db,"samples",quiet=TRUE)
cache <- prepare_isovist_engine(obstacles)
ids <- unique(c(seq(1,nrow(samples),length.out=8) |> round(),
  which.max(samples$distance_to_axis_m),which(samples$in_previously_unfilled_area)[1]))
ids <- ids[!is.na(ids)]
rows <- lapply(ids,function(i) {
  xy <- as.numeric(st_coordinates(samples[i,]))
  t0 <- proc.time()[3]; original <- cast_isovist_reference(xy,obstacles); reference_s <- proc.time()[3]-t0
  t0 <- proc.time()[3]; fast <- cast_isovist(xy,obstacles,cache=cache); indexed_s <- proc.time()[3]-t0
  endpoint_error <- max(abs(original$endpoints-fast$endpoints))
  difference <- suppressWarnings(st_sym_difference(original$geometry,fast$geometry))
  area_error <- if(length(difference))sum(as.numeric(st_area(difference))) else 0
  stopifnot(endpoint_error<1e-7,area_error<1e-4)
  data.frame(sample_id=i,endpoint_error_m=endpoint_error,symmetric_difference_m2=area_error,
    reference_seconds=reference_s,indexed_seconds=indexed_s)
}) |> bind_rows()
write.csv(rows,file.path(output_dir,"engine-regression-check.csv"),row.names=FALSE)
write_report(list(passed=TRUE,checked_samples=nrow(rows),
  max_endpoint_error_m=max(rows$endpoint_error_m),max_symmetric_difference_m2=max(rows$symmetric_difference_m2),
  reference_seconds=sum(rows$reference_seconds),indexed_seconds=sum(rows$indexed_seconds),
  method="Exact first-hit intersections with conservative angular candidate indexing; unchanged ray directions."),"engine-validation.json")
print(rows)
