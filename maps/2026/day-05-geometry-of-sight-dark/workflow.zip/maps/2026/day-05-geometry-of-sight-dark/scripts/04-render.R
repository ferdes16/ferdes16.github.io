source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
suppressPackageStartupMessages({library(ggplot2);library(grid)})
stopifnot(isTRUE(read_json(file.path(output_dir,"analysis-validation.json"))$passed))
visibility <- readRDS(file.path(processed_dir,"visibility.rds"))
db <- file.path(processed_dir,"geometry-of-sight.gpkg")
obstacles <- st_read(db,"obstacles",quiet=TRUE)
scene <- readRDS(file.path(processed_dir,"scene.rds"))
paper <- "#0A151D"; ink <- "#EDF5F1"; muted <- "#9DB2B1"
palette <- c("#294D5F","#2C8C99","#42C6B5","#B9E5C5","#F3C878")
values <- c(0,.25,.52,.78,1)
limits <- c(0,30000)
above <- sum(visibility$samples$visible_area_m2>30000)
display_grid <- terra::rast(xmin=scene$extent[1],xmax=scene$extent[3],
  ymin=scene$extent[2],ymax=scene$extent[4],resolution=.5,crs=st_crs(obstacles)$wkt)
display_grid <- terra::rasterize(terra::vect(visibility$cells),display_grid,
  field="visible_area_m2",background=NA_real_,touches=FALSE)
names(display_grid) <- "visible_area_m2"
terra::writeRaster(display_grid,file.path(processed_dir,"visibility-display-0.5m.tif"),
  overwrite=TRUE,gdal="COMPRESS=DEFLATE")
display_values <- terra::as.data.frame(display_grid,xy=TRUE,na.rm=FALSE)
map <- ggplot() +
  geom_raster(data=display_values,aes(x=x,y=y,fill=visible_area_m2),interpolate=TRUE) +
  geom_sf(data=obstacles,fill="#21313B",colour=NA) +
  scale_fill_gradientn(colours=palette,values=values,limits=limits,oob=scales::squish,na.value="transparent") +
  coord_sf(xlim=scene$extent[c(1,3)],ylim=scene$extent[c(2,4)],datum=NA,expand=FALSE) +
  theme_void() + theme(legend.position="none",plot.margin=margin(0,0,0,0),
    panel.background=element_rect(fill=paper,colour=NA),plot.background=element_rect(fill=paper,colour=NA))
text_at <- function(label,x,y,size=11,colour=ink,face="plain",just="left",family="Avenir Next")
  grid.text(label,x,y,just=just,gp=gpar(fontfamily=family,fontsize=size,col=colour,fontface=face))
draw_poster <- function(file,width,height,res) {
  ragg::agg_png(file,width=width,height=height,res=res,background=paper)
  grid.newpage()
  text_at("BARCELONA / L'EIXAMPLE",.055,.973,9,muted,face="bold")
  text_at("HOW FAR CAN YOU SEE?",.052,.932,52,face="bold",family="DIN Condensed")
  # Map is a true 9 × 9 inch square in the 10 × 12 inch poster.
  print(map,newpage=FALSE,vp=viewport(x=.5,y=.515,width=.90,height=.75))
  scale_width <- .90*50/700
  scale_label_width <- convertWidth(grobWidth(textGrob("50 m",
    gp=gpar(fontfamily="Avenir Next",fontsize=7.5,fontface="bold"))),"npc",valueOnly=TRUE)
  scale_right <- .945-scale_label_width-.012
  scale_left <- scale_right-scale_width
  grid.rect(x=scale_left+scale_width/4,y=.123,width=scale_width/2,height=.0035,
    gp=gpar(fill="#D5E7DF",col=NA))
  grid.rect(x=scale_left+3*scale_width/4,y=.123,width=scale_width/2,height=.0035,
    gp=gpar(fill="#5C8F91",col=NA))
  text_at("50 m",.945,.123,7.5,ink,face="bold",just="right")
  text_at("VISIBLE AREA (m²)",.055,.098,9,face="bold")
  text_at("360° view · 150 m sight limit · 5 m sampling grid",.945,.098,8.4,muted,just="right")
  colours <- scales::gradient_n_pal(palette,values=values)(seq(0,1,length.out=500))
  grid.raster(as.raster(matrix(colours,nrow=1)),x=.5,y=.078,width=.89,height=.010,interpolate=TRUE)
  for(value in c(0,10000,20000,30000))text_at(paste0(if(value==30000&&above>0)"≥" else "",
    format(value,big.mark=",",trim=TRUE,scientific=FALSE)),.055+.89*value/30000,.061,8,muted,just="centre")
  text_at("© OpenStreetMap contributors · ODbL 1.0 · openstreetmap.org/copyright",.055,.017,6.4,"#789391")
  text_at("#30DayMapChallenge 2026",.945,.036,6.8,muted,just="right")
  text_at("Day 5 — Senses: Sight",.945,.023,6.8,muted,just="right")
  text_at("@mappedbyfer",.945,.010,6.8,muted,face="bold",just="right")
  invisible(dev.off())
}
stem <- "the-geometry-of-sight-eixample-dark"
draw_poster(file.path(output_dir,paste0(stem,"-portfolio.png")),3000,3600,300)
draw_poster(file.path(output_dir,paste0(stem,"-preview.png")),1500,1800,150)
write_report(list(title="HOW FAR CAN YOU SEE?",area="Eixample",extent_dimensions_m=c(700,700),
  legend_label="VISIBLE AREA (m²)",
  subtitle_displayed=FALSE,osm_base_line_displayed=FALSE,
  geographic_scale_position="Immediately below the map, right",geographic_scale_m=50,
  geographic_scale_y=.123,geographic_scale_style="Minimal two-tone bar, two 25 m segments",
  map_viewport=list(x=.5,y=.515,width=.90,height=.75),
  background=paper,buildings="#21313B",palette=palette,palette_values=values,
  colour_limits_m2=limits,values_above_display_cap=above,upper_cap_marked=above>0,
  metric="Actual 2D isovist area at each 5 m open-space cell observer",
  extrapolated_axis_values=FALSE,metric_smoothing=FALSE,sampling_resolution_m=5,
  display_raster_resolution_m=.5,renderer_bilinear_interpolation=TRUE,
  explicit_cell_strokes=FALSE,raw_metrics_modified=FALSE,
  portfolio_dimensions=c(3000,3600),preview_dimensions=c(1500,1800)),"render-info.json")
writeLines(sub("[[:blank:]]+$","",capture.output(sessionInfo())),file.path(output_dir,"session-info.txt"))
message("Dark 700 × 700 m Eixample poster and preview exported.")
