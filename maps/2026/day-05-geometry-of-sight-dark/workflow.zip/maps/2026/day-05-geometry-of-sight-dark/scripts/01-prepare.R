source(file.path(dirname(sub("^--file=","",grep("^--file=",commandArgs(),value=TRUE)[1])),"common.R"))
osm <- readRDS(file.path(raw_dir,"osmdata.rds"))
sources <- read_json(file.path(raw_dir,"sources-original.json"))
stopifnot(unname(tools::md5sum(file.path(raw_dir,"eixample.osm")))==sources$raw_md5)
centre <- c(430010,4582670)
extent <- c(xmin=centre[1]-350,ymin=centre[2]-350,xmax=centre[1]+350,ymax=centre[2]+350)
study_area <- st_sf(geometry=st_as_sfc(st_bbox(extent,crs=analysis_crs)))
envelope <- st_buffer(study_area,155)
source_bbox <- st_as_sfc(st_bbox(c(xmin=2.154,ymin=41.386,xmax=2.172,ymax=41.400),crs=4326)) |>
  st_transform(analysis_crs)
stopifnot(all(lengths(st_within(st_buffer(study_area,150),source_bbox))==1))
buildings <- bind_rows(lapply(c("osm_polygons","osm_multipolygons"),function(layer) {
  x <- osm[[layer]]
  x <- x[!is.na(tag(x,"building")) & !has_tag(x,"building",c("no","roof","construction","ruins")) &
    !has_tag(x,"location","underground") & !has_tag(x,"layer",c("-1","-2","-3")),]
  st_sf(osm_id=x$osm_id,source_layer=layer,building=x$building,
    geometry=st_geometry(st_transform(x,analysis_crs)))
}))
buildings <- buildings[lengths(st_intersects(buildings,envelope))>0,]
invalid_before <- sum(!st_is_valid(buildings))
buildings <- st_make_valid(buildings)
buildings <- buildings[!st_is_empty(buildings),]
equals <- st_equals(buildings)
keep <- vapply(seq_along(equals),function(i)!any(equals[[i]]<i),logical(1))
duplicates <- sum(!keep); buildings <- buildings[keep,]
obstacles <- st_sf(geometry=st_cast(st_make_valid(st_union(st_geometry(buildings))),"POLYGON",warn=FALSE))
streets <- st_transform(osm$osm_lines,analysis_crs)
classes <- c("primary","secondary","tertiary","residential","unclassified",
  "living_street","pedestrian","primary_link","secondary_link","tertiary_link")
streets <- streets[has_tag(streets,"highway",classes) &
  !has_tag(streets,"access",c("private","no")) & !has_tag(streets,"foot",c("no","private")) &
  !has_tag(streets,"indoor","yes") & !has_tag(streets,"tunnel",c("yes","building_passage")) &
  !has_tag(streets,"layer",c("-1","-2","-3")) & !has_tag(streets,"bridge","yes") &
  lengths(st_intersects(streets,study_area))>0,]
streets <- suppressWarnings(st_intersection(streets,st_geometry(study_area)))
streets <- streets[!st_is_empty(streets) & as.numeric(st_length(streets))>.05,]
network <- st_sf(geometry=st_cast(st_union(st_geometry(streets)),"LINESTRING",warn=FALSE))

# Publicly tagged pedestrian areas explicitly support sampling within plazas.
p <- osm$osm_polygons
p <- p[has_tag(p,"highway","pedestrian") & !has_tag(p,"access",c("private","no")) &
  !has_tag(p,"foot",c("no","private")) & !has_tag(p,"indoor","yes") &
  !has_tag(p,"layer",c("-1","-2","-3")),]
p <- st_transform(p,analysis_crs)
p <- p[lengths(st_intersects(p,study_area))>0,]
pedestrian_areas <- st_sf(osm_id=p$osm_id,name=tag(p,"name"),geometry=st_geometry(st_make_valid(p)))
pedestrian_areas <- suppressWarnings(st_intersection(pedestrian_areas,st_geometry(study_area)))

# Remove the former 35 m display cap. Retain street-connected open components
# and explicitly mapped pedestrian areas, while excluding isolated courtyards.
facade_gap <- .6
free <- st_difference(st_geometry(study_area),st_union(st_buffer(st_geometry(obstacles),facade_gap)))
components <- st_cast(st_make_valid(free),"POLYGON",warn=FALSE)
connected <- lengths(st_intersects(components,network))>0
pedestrian <- if(nrow(pedestrian_areas))lengths(st_intersects(components,pedestrian_areas))>0 else FALSE
domain <- st_sf(geometry=st_union(components[connected | pedestrian]))
old_style <- st_intersection(st_geometry(domain),st_buffer(st_union(st_geometry(network)),35))
new_open_space <- st_sf(geometry=st_difference(st_geometry(domain),old_style))

# Each clipped square component receives its own genuine observer, including
# plaza interiors far from street axes. No colour is extrapolated across walls.
grid <- st_make_grid(study_area,cellsize=5,square=TRUE)
grid_sf <- st_sf(grid_id=seq_along(grid),geometry=grid)
cells <- suppressWarnings(st_intersection(grid_sf,st_geometry(domain)))
cells <- cells[!st_is_empty(cells) & st_dimension(cells)==2,]
cells <- suppressWarnings(st_cast(st_cast(cells,"MULTIPOLYGON"),"POLYGON"))
tiny_area <- sum(as.numeric(st_area(cells))[as.numeric(st_area(cells))<=1e-6])
cells <- cells[as.numeric(st_area(cells))>1e-6,]
cells$sample_id <- seq_len(nrow(cells))
cells$cell_area_m2 <- as.numeric(st_area(cells))
samples <- suppressWarnings(st_point_on_surface(cells))
samples$distance_to_axis_m <- as.numeric(st_distance(samples,st_union(network)))
samples$in_previously_unfilled_area <- lengths(st_intersects(samples,new_open_space))>0
samples$in_mapped_pedestrian_area <- if(nrow(pedestrian_areas))
  lengths(st_intersects(samples,pedestrian_areas))>0 else FALSE
stopifnot(all(st_is_valid(obstacles)),all(st_is_valid(cells)),
  all(lengths(st_intersects(samples,obstacles))==0),
  min(as.numeric(st_distance(samples,st_union(obstacles))))>=facade_gap-1e-6,
  abs(sum(cells$cell_area_m2)-sum(as.numeric(st_area(domain))))<.001)
for(layer in c("study_area","buildings","obstacles","streets","network","pedestrian_areas",
               "domain","new_open_space","cells","samples"))write_layer(get(layer),layer)
saveRDS(list(extent=extent,view_radius_m=150,sampling_m=5,facade_gap_m=facade_gap),file.path(processed_dir,"scene.rds"))
write_report(sources,"sources.json")
write_report(list(extent_m=extent,dimensions_m=c(700,700),added_extent_each_side_m=100,
  source_building_records=nrow(buildings),invalid_before_repair=invalid_before,
  duplicate_geometries_removed=duplicates,obstacle_polygons=nrow(obstacles),
  street_ways=nrow(streets),sample_count=nrow(samples),sampling_grid_m=5,
  sampled_open_space_m2=sum(cells$cell_area_m2),newly_covered_beyond_35m_cap_m2=sum(as.numeric(st_area(new_open_space))),
  observers_in_previously_unfilled_area=sum(samples$in_previously_unfilled_area),
  observers_over_15m_from_axis=sum(samples$distance_to_axis_m>15),
  observers_in_mapped_pedestrian_areas=sum(samples$in_mapped_pedestrian_area),
  isolated_components_excluded=sum(!(connected|pedestrian)),tiny_sliver_area_excluded_m2=tiny_area,
  building_overlap_observers=0,full_150m_viewing_margin_covered_by_raw_source=TRUE),"geometry-validation.json")
message(nrow(samples)," genuine 2D observers across ",round(sum(cells$cell_area_m2))," m² of streets and open areas.")
