entry <- sub("^--file=", "", grep("^--file=", commandArgs(FALSE), value = TRUE)[1])
project_dir <- normalizePath(file.path(dirname(entry), ".."), mustWork = TRUE)
raw_dir <- file.path(project_dir, "data/raw")
processed_dir <- file.path(project_dir, "data/processed")
output_dir <- file.path(project_dir, "output")
local_library <- file.path(project_dir, "data/library")
for (directory in c(raw_dir, processed_dir, output_dir, local_library))
  dir.create(directory, recursive = TRUE, showWarnings = FALSE)
.libPaths(c(local_library, .libPaths()))
suppressPackageStartupMessages({ library(sf); library(dplyr); library(jsonlite) })
analysis_crs <- 25831L
view_radius <- 150
write_report <- function(value, filename) {
  write_json(value, file.path(output_dir, filename), pretty = TRUE,
             auto_unbox = TRUE, digits = 10, na = "null")
}
write_layer <- function(x, layer) {
  st_write(x, file.path(processed_dir, "geometry-of-sight.gpkg"), layer = layer,
           delete_layer = TRUE, quiet = TRUE)
}
tag <- function(x, field) {
  if (field %in% names(x)) as.character(x[[field]]) else rep(NA_character_, nrow(x))
}
has_tag <- function(x, field, values) !is.na(tag(x, field)) & tag(x, field) %in% values

# Preserve all original polygon rings, including courtyard holes.
boundary_segments <- function(polygons) {
  # Avoid casting a mixed LINESTRING/MULTILINESTRING boundary collection,
  # which can silently keep only the first ring of polygons with courtyards.
  rings <- unlist(lapply(st_geometry(polygons), unclass), recursive = FALSE)
  result <- lapply(rings, function(ring) {
    xy <- ring[, 1:2, drop = FALSE]
    cbind(xy[-nrow(xy), , drop = FALSE], xy[-1, , drop = FALSE])
  })
  segments <- do.call(rbind, result)
  segments[rowSums((segments[, 1:2] - segments[, 3:4])^2) > 1e-16, , drop = FALSE]
}

# First-hit ray/segment intersections, in projected metres. Each regular angle
# is supplemented by every nearby obstacle vertex and small offsets on each
# side: this resolves occlusion transitions at the real chamfered corners.
cast_isovist <- function(observer, obstacles, radius = view_radius,
                         angle_step_degrees = 0.25, vertex_epsilon = 1e-7) {
  point <- st_sfc(st_point(observer), crs = analysis_crs)
  search_box <- st_as_sfc(st_bbox(st_buffer(point, radius + 0.01)))
  candidates <- obstacles[lengths(st_intersects(obstacles, search_box)) > 0, ]
  near <- lengths(st_is_within_distance(candidates, point, dist = radius + 0.01)) > 0
  segments <- boundary_segments(candidates[near, ])
  vertices <- unique(rbind(segments[, 1:2], segments[, 3:4]))
  vertices <- vertices[rowSums(sweep(vertices, 2, observer)^2) <= (radius + 0.01)^2, , drop = FALSE]
  bearings <- atan2(vertices[, 2] - observer[2], vertices[, 1] - observer[1])
  angles <- sort(unique(c(seq(0, 2*pi, length.out = 360/angle_step_degrees + 1)[-1],
                          bearings - vertex_epsilon, bearings, bearings + vertex_epsilon) %% (2*pi)))
  ax <- segments[, 1] - observer[1]
  ay <- segments[, 2] - observer[2]
  sx <- segments[, 3] - segments[, 1]
  sy <- segments[, 4] - segments[, 2]
  numerator <- ax*sy - ay*sx
  hit <- vapply(angles, function(angle) {
    dx <- cos(angle); dy <- sin(angle)
    denominator <- dx*sy - dy*sx
    distance <- numerator / denominator
    fraction <- (ax*dy - ay*dx) / denominator
    valid <- is.finite(distance) & abs(denominator) > 1e-12 &
      distance >= -1e-9 & fraction >= -1e-10 & fraction <= 1 + 1e-10
    # A sub-millimetre setback avoids roundoff extending through a facade.
    max(0, min(c(radius, distance[valid])) - 1e-5)
  }, numeric(1))
  endpoints <- cbind(observer[1] + hit*cos(angles), observer[2] + hit*sin(angles))
  polygon <- st_sfc(st_polygon(list(rbind(endpoints, endpoints[1, ]))), crs = analysis_crs)
  stopifnot(st_is_valid(polygon), !st_is_empty(polygon))
  list(geometry = polygon, ray_count = length(angles), endpoints = endpoints,
       max_endpoint_distance = max(hit))
}

# Sample an existing polyline by true cumulative length, without smoothing it
# across corners or moving it away from its mapped pedestrian geometry.
sample_polyline <- function(xy, distances) {
  lengths <- sqrt(rowSums((xy[-1, , drop = FALSE] - xy[-nrow(xy), , drop = FALSE])^2))
  cumulative <- c(0, cumsum(lengths))
  stopifnot(all(distances >= 0), max(distances) <= tail(cumulative, 1) + 1e-7)
  segment <- pmin(findInterval(distances, cumulative), length(lengths))
  fraction <- (distances - cumulative[segment]) / lengths[segment]
  xy[segment, , drop = FALSE] + (xy[segment + 1, , drop = FALSE] - xy[segment, , drop = FALSE])*fraction
}
