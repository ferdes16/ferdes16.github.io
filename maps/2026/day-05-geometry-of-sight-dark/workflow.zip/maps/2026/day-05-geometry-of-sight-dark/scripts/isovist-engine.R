Rcpp::sourceCpp(file.path(project_dir,"scripts/ray-casting.cpp"),
                cacheDir=file.path(processed_dir,"native-cache"),showOutput=FALSE)
cast_isovist_reference <- cast_isovist
prepare_isovist_engine <- function(obstacles) {
  segments <- boundary_segments(obstacles)
  list(segments=segments,vertices=unique(rbind(segments[,1:2],segments[,3:4])))
}
cast_isovist <- function(observer,obstacles,radius=view_radius,
                         angle_step_degrees=.25,vertex_epsilon=1e-7,cache=NULL) {
  if(is.null(cache))cache <- prepare_isovist_engine(obstacles)
  segments <- cache$segments
  vertices <- cache$vertices
  vertices <- vertices[(vertices[,1]-observer[1])^2+(vertices[,2]-observer[2])^2 <= (radius+.01)^2,,drop=FALSE]
  bearings <- atan2(vertices[,2]-observer[2],vertices[,1]-observer[1])
  angles <- sort(unique(c(seq(0,2*pi,length.out=360/angle_step_degrees+1)[-1],
                          bearings-vertex_epsilon,bearings,bearings+vertex_epsilon) %% (2*pi)))
  result <- first_hits_indexed(observer,segments,angles,radius)
  endpoints <- result$endpoints
  geometry <- st_sfc(st_polygon(list(rbind(endpoints,endpoints[1,]))),crs=analysis_crs)
  stopifnot(st_is_valid(geometry),!st_is_empty(geometry))
  list(geometry=geometry,ray_count=length(angles),endpoints=endpoints,
    max_endpoint_distance=max(result$distances),segment_tests=result$segment_tests)
}
